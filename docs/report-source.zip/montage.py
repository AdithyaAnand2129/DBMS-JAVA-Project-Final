from PIL import Image, ImageDraw
import glob, os
files=glob.glob('tmp/pdfs/report-final/page-*.png')
files=sorted(files,key=lambda p:int(os.path.basename(p).split('-')[-1].split('.')[0]))
pages=[]
for path in files:
    im=Image.open(path).convert('RGB')
    im.thumbnail((306,432))
    pages.append((path,im.copy()))
out=Image.new('RGB',(306*3,452*((len(pages)+2)//3)),(220,225,230))
draw=ImageDraw.Draw(out)
for i,(path,im) in enumerate(pages):
    x=(i%3)*306; y=(i//3)*452
    out.paste(im,(x,y))
    draw.text((x+6,y+434),os.path.basename(path),fill=(0,0,0))
out.save('tmp/pdfs/contact-final.png')
