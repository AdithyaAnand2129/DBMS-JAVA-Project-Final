from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak,
    Table, TableStyle, Preformatted, Flowable, NextPageTemplate)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.platypus import Image as RLImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from PIL import Image as PILImage
from xml.sax.saxutils import escape
import os

OUT='output/pdf/RoomWise_Final_Project_Report.pdf'
LOGO='tmp/rec_logo_flat.png'
_logo=PILImage.open('tmp/rec_logo.png').convert('RGBA')
_white=PILImage.new('RGBA',_logo.size,(255,255,255,255)); _white.alpha_composite(_logo); _white.convert('RGB').save(LOGO)
pdfmetrics.registerFont(TTFont('Arial','C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Bold','C:/Windows/Fonts/arialbd.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Italic','C:/Windows/Fonts/ariali.ttf'))
NAVY=HexColor('#333333'); BLUE=HexColor('#555555'); TEAL=HexColor('#777777'); PALE=HexColor('#F2F2F2'); INK=HexColor('#222222'); MUTED=HexColor('#666666')
PAGE_W,PAGE_H=A4

class ReportDoc(BaseDocTemplate):
    def __init__(self, filename, **kw):
        super().__init__(filename, **kw)
        frame=Frame(22*mm,19*mm,PAGE_W-44*mm,PAGE_H-39*mm,id='normal',leftPadding=0,rightPadding=0,topPadding=2*mm,bottomPadding=2*mm)
        self.addPageTemplates([PageTemplate(id='Cover',frames=frame,onPage=self.cover_page),PageTemplate(id='Body',frames=frame,onPage=self.body_page)])
    def cover_page(self,c,doc):
        c.saveState(); c.setStrokeColor(HexColor('#A7A7A7')); c.setLineWidth(.7); c.rect(8*mm,8*mm,PAGE_W-16*mm,PAGE_H-16*mm,fill=0,stroke=1); c.restoreState()
    def body_page(self,c,doc):
        if doc.page < 5:
            return
        c.saveState(); c.setStrokeColor(HexColor('#D7E1E8')); c.setLineWidth(.6); c.line(22*mm,PAGE_H-15*mm,PAGE_W-22*mm,PAGE_H-15*mm)
        c.setFont('Times-Bold',9); c.setFillColor(INK); c.drawString(22*mm,PAGE_H-12*mm,'ROOMWISE PROJECT REPORT')
        c.setFont('Times-Roman',9); c.setFillColor(INK); c.drawRightString(PAGE_W-22*mm,PAGE_H-12*mm,f'{doc.page}')
        c.line(22*mm,PAGE_H-15*mm,PAGE_W-22*mm,PAGE_H-15*mm); c.restoreState()
    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and getattr(flowable,'_toc_level',None) is not None:
            text=flowable.getPlainText(); key='h%d-%d'%(flowable._toc_level,self.page)
            self.canv.bookmarkPage(key); self.canv.addOutlineEntry(text,key,flowable._toc_level,False)
            self.notify('TOCEntry',(flowable._toc_level,text,self.page,key))

ss=getSampleStyleSheet()
styles={}
styles['Title']=ParagraphStyle('Title',fontName='Times-Bold',fontSize=27,leading=34,textColor=colors.black,alignment=TA_CENTER,spaceAfter=12)
styles['SubTitle']=ParagraphStyle('SubTitle',fontName='Times-Roman',fontSize=14,leading=20,textColor=INK,alignment=TA_CENTER,spaceAfter=8)
styles['H1']=ParagraphStyle('H1',fontName='Times-Bold',fontSize=16,leading=21,textColor=colors.black,alignment=TA_CENTER,spaceBefore=4,spaceAfter=10,keepWithNext=True)
styles['H2']=ParagraphStyle('H2',fontName='Times-Bold',fontSize=12.5,leading=17,textColor=INK,spaceBefore=10,spaceAfter=5,keepWithNext=True)
styles['Body']=ParagraphStyle('Body',fontName='Times-Roman',fontSize=10.5,leading=16,textColor=INK,alignment=TA_JUSTIFY,spaceAfter=8)
styles['Small']=ParagraphStyle('Small',fontName='Times-Roman',fontSize=9,leading=12,textColor=MUTED,spaceAfter=4)
styles['Bullet']=ParagraphStyle('Bullet',parent=styles['Body'],leftIndent=14,firstLineIndent=-8,bulletIndent=1,spaceAfter=4)
styles['Center']=ParagraphStyle('Center',fontName='Times-Roman',fontSize=11,leading=16,textColor=INK,alignment=TA_CENTER,spaceAfter=6)
styles['CoverName']=ParagraphStyle('CoverName',fontName='Times-Bold',fontSize=12,leading=18,textColor=INK,alignment=TA_CENTER,spaceAfter=6)
styles['CertificateBody']=ParagraphStyle('CertificateBody',fontName='Times-Roman',fontSize=11,leading=18,textColor=INK,alignment=0,spaceAfter=8)
styles['Code']=ParagraphStyle('Code',fontName='Courier',fontSize=7.2,leading=9.4,textColor=INK,backColor=HexColor('#F4F7F9'),borderColor=HexColor('#D6E1E8'),borderWidth=.5,borderPadding=6,spaceBefore=4,spaceAfter=7)
styles['Caption']=ParagraphStyle('Caption',fontName='Times-Italic',fontSize=9,leading=12,textColor=MUTED,alignment=TA_CENTER,spaceAfter=8)
styles['IndexPage']=ParagraphStyle('IndexPage',fontName='Times-Roman',fontSize=10.5,leading=16,textColor=INK,alignment=2)
story=[]
def P(txt,style='Body'): story.append(Paragraph(txt,styles[style]))
def H(txt,level=0):
    p=Paragraph(txt,styles['H1'] if level==0 else styles['H2']); p._toc_level=level; story.append(p)
def bullets(items):
    for x in items: story.append(Paragraph('&#8226; '+x,styles['Bullet']))
def tbl(data,widths=None,header=True,font=8,caption=None):
    cell_style=ParagraphStyle('tablebody',fontName='Times-Roman',fontSize=font,leading=font+2,wordWrap='CJK',textColor=INK)
    head_style=ParagraphStyle('tablehead',fontName='Times-Bold',fontSize=font,leading=font+2,wordWrap='CJK',textColor=colors.black)
    wrapped=[[Paragraph(escape(str(cell)),head_style if header and row==0 else cell_style) for cell in line] for row,line in enumerate(data)]
    t=Table(wrapped,colWidths=widths,repeatRows=1 if header else 0,hAlign='LEFT')
    cmds=[('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.35,HexColor('#CFD9DF')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('FONTNAME',(0,0),(-1,-1),'Arial'),('FONTSIZE',(0,0),(-1,-1),font),('TEXTCOLOR',(0,0),(-1,-1),INK)]
    if header: cmds += [('BACKGROUND',(0,0),(-1,0),HexColor('#E7E7E7')),('TEXTCOLOR',(0,0),(-1,0),colors.black),('FONTNAME',(0,0),(-1,0),'Times-Bold')]
    for row in range(1 if header else 0,len(data)):
        if row%2==0: cmds.append(('BACKGROUND',(0,row),(-1,row),HexColor('#F2F6F8')))
    cmds=[tuple([*cmd[:3],('Times-Roman' if cmd[3]=='Arial' else ('Times-Bold' if cmd[3]=='Arial-Bold' else cmd[3])),*cmd[4:]]) if cmd[0]=='FONTNAME' else cmd for cmd in cmds]
    t.setStyle(TableStyle(cmds)); story.append(t)
    if caption: story.append(Paragraph(caption,styles['Caption']))
    story.append(Spacer(1,5))
def indexline(label,page):
    row=Table([[Paragraph(label,styles['Body']),Paragraph(str(page),styles['IndexPage'])]],colWidths=[150*mm,12*mm],hAlign='LEFT')
    row.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),('TOPPADDING',(0,0),(-1,-1),1),('BOTTOMPADDING',(0,0),(-1,-1),1)]))
    story.append(row)
def borderless_columns(data,widths,bold_first=True):
    rows=[[Paragraph(str(cell),ParagraphStyle('sigcell',fontName='Times-Bold' if bold_first and i==0 else 'Times-Roman',fontSize=10.5,leading=16,textColor=INK)) for cell in row] for i,row in enumerate(data)]
    t=Table(rows,colWidths=widths,hAlign='LEFT')
    cmds=[('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]
    t.setStyle(TableStyle(cmds)); story.append(t); story.append(Spacer(1,6))

# Cover
story += [Spacer(1,18*mm),Paragraph('ROOMWISE',styles['Title']),Paragraph('Smart Campus Room Finder and Scheduling System',styles['SubTitle']),Spacer(1,5*mm)]
story.append(Paragraph('OOP USING JAVA AND DBMS PROJECT REPORT',ParagraphStyle('coverreport',fontName='Times-Bold',fontSize=15,leading=20,textColor=INK,alignment=TA_CENTER,spaceAfter=8)))
story.append(Spacer(1,9*mm)); story.append(Paragraph('Report submitted by',styles['Center']))
story.append(Paragraph('[Student name(s) and roll number(s)]',styles['CoverName']))
story += [Spacer(1,7*mm),Paragraph('Bachelor of Engineering in Computer Science and Engineering',styles['Center']),Spacer(1,8*mm)]
story.append(Paragraph('RAJALAKSHMI ENGINEERING COLLEGE, THANDALAM',styles['CoverName']))
story.append(Paragraph('An Autonomous Institution Affiliated to Anna University',styles['Center']))
story.append(Spacer(1,4*mm)); story.append(RLImage(LOGO,width=55*mm,height=27.5*mm,hAlign='CENTER'))
story += [Spacer(1,4*mm),Paragraph('[Academic Year]',styles['CoverName']),NextPageTemplate('Body'),PageBreak()]

# Preliminary pages
story.append(RLImage(LOGO,width=50*mm,height=25*mm,hAlign='CENTER')); story.append(Spacer(1,4*mm)); H('BONAFIDE CERTIFICATE',0)
P('Certified that this is the bonafide record of the project titled <b>"ROOMWISE: SMART CAMPUS ROOM FINDER AND SCHEDULING SYSTEM"</b> done by <b>[Student name(s) and roll number(s)]</b>, who carried out the project work under our supervision during the academic year <b>[Academic Year]</b>.','CertificateBody')
story.append(Spacer(1,20*mm))
borderless_columns([['[Project Guide 1]','[Project Guide 2]'],['Faculty in-charge','Faculty in-charge'],['OOP using Java','Database Management Systems'],['Department of Computer Science and Engineering','Department of Computer Science and Engineering']],[78*mm,78*mm])
story.append(Spacer(1,10*mm)); P('Submitted for the Practical Examination held on  __________________','CertificateBody')
story.append(Spacer(1,18*mm)); borderless_columns([['Internal Examiner','External Examiner']],[78*mm,78*mm]); story.append(PageBreak())
H('STUDENT DECLARATION',0)
P('We, <b>[Student name(s) and roll number(s)]</b>, students of the Department of Computer Science and Engineering, Rajalakshmi Engineering College, hereby declare that the project report entitled <b>"ROOMWISE: SMART CAMPUS ROOM FINDER AND SCHEDULING SYSTEM"</b> is a record of the work carried out by us as part of the Object-Oriented Programming using Java and Database Management Systems project.')
P('We further declare that this project has been developed by us using Java, JDBC, and MySQL. This report describes the implementation available in the project source and identifies features that remain incomplete. References to external material and supplied data are listed in the References section.')
P('Place: Thandalam<br/>Date: __________________')
story.append(Spacer(1,18*mm)); borderless_columns([['Student name(s) and roll number(s)',''],['[Name(s) and number(s)]','________________________']],[105*mm,53*mm])
story.append(PageBreak()); H('ACKNOWLEDGEMENT',0)
P('We express our sincere thanks to our project guide, [Guide name], for guidance and feedback during the development of RoomWise. We thank the Department of [Department name] and [Institution name] for the opportunity to complete this project as part of the OOPs and DBMS course.')
P('We also acknowledge the maintainers of Java, MySQL, JDBC, and MySQL Connector/J, which provide the core platform and database connectivity used in this project. The supplied college theory and laboratory timetable data enabled us to demonstrate room and class lookup against a realistic dataset.')
P('The names and acknowledgements above must be reviewed and completed by the project team before submission.')
story.append(PageBreak()); H('ABSTRACT',0)
P('RoomWise is a Java application for browsing campus timetable availability. It connects to a MySQL database through JDBC and presents a Swing interface with weekday and time filters. Users can view rooms that are free at a selected time, view scheduled classes that overlap a selected time, browse the campus room list, and create a same-day room booking from the console interface.')
P('The database currently stores rooms, recurring weekly timetable slots, and dated bookings. The supplied theory and laboratory timetable data are normalized into 4,167 timetable rows across 157 rooms. SQL queries use PreparedStatement parameters. The booking workflow checks for timetable and booking interval overlaps inside a JDBC transaction before inserting a booking. The project therefore demonstrates a practical Java-to-MySQL workflow, relational keys, SQL filtering, and basic transaction handling.')
P('This report intentionally distinguishes implemented functionality from the broader OOP and DBMS assignment requirements. The current source is a single Java file in one package and uses records and utility classes; it does not yet provide the complete class hierarchy, interfaces, or full CRUD coverage expected for a comprehensive OOP demonstration. Bookings can be created but not edited or cancelled through the application. These gaps are documented as limitations and future work.')
P('<b>Keywords:</b> Java, JDBC, MySQL, room availability, timetable, transaction, Swing, database design.')
story.append(PageBreak()); H('TABLE OF CONTENTS',0)
toc=TableOfContents(); toc.levelStyles=[ParagraphStyle('TOC0',fontName='Times-Bold',fontSize=10.5,leading=16,leftIndent=0,textColor=INK,spaceBefore=3),ParagraphStyle('TOC1',fontName='Times-Roman',fontSize=9.5,leading=14,leftIndent=12,textColor=INK)]
story.append(toc); story.append(PageBreak())
H('LIST OF FIGURES',0)
indexline('Figure 3.1  Current application data path',12)
indexline('Figure 4.1  Entity relationship view of the implemented schema',13)
indexline('Figure B.1  Free-room search results',20)
indexline('Figure B.2  Occupied-class search results',21)
story.append(PageBreak())
H('LIST OF TABLES',0)
indexline('Table 1.1  Current users and system interactions',10)
indexline('Table 2.1  Functional requirements traceability',11)
indexline('Table 2.2  Hardware and software requirements',11)
indexline('Table 3.1  OOP concept mapping in the current code',13)
indexline('Table 4.1  Database tables and important columns',14)
indexline('Table 5.1  Technology stack',15)
indexline('Table 5.2  Implemented database operations',16)
indexline('Table 6.1  Verification performed during report preparation',16)
indexline('Table 6.2  Manual functional test cases',16)
story.append(PageBreak())

# Chapter 1
H('CHAPTER 1: INTRODUCTION',0)
H('1.1 Background',1)
P('Campus rooms are shared resources used for lectures, laboratory classes, meetings, and student work. When timetable information is stored in separate files or checked manually, it can take time to determine whether a room is occupied at a particular day and time. RoomWise places recurring timetable data in a relational database and provides a simple interface for checking room status.')
H('1.2 Problem statement',1)
P('The project addresses the task of finding rooms that are free at a selected point in the weekly timetable and locating classes that occupy rooms during a requested interval. It also provides a basic way for a teacher to reserve a currently free room for the remainder of the same day, subject to the timetable and booking overlap checks.')
H('1.3 Objectives',1)
bullets(['Import and query a realistic college timetable in MySQL.','Display rooms available at a selected weekday and time.','Display scheduled classes overlapping a selected time interval.','Provide a same-day room booking action through the console menu.','Demonstrate Java Swing, JDBC PreparedStatements, relational constraints, and a transaction-based insert workflow.','Record incomplete requirements honestly and identify next development steps.'])
H('1.4 Scope',1)
P('The implemented scope is timetable browsing and a minimal booking workflow. The database contains room names, recurring timetable entries, and dated bookings. The current user interface does not provide authentication, roles, room capacity or equipment filters, administration screens, or booking update and delete operations. It does not attempt to synchronize with an external timetable service.')
H('1.5 Users and use cases',1)
tbl([['Actor','Current interaction'],['Student / visitor','View free rooms and occupied classes in the Swing window or console.'],['Teacher','Use the console menu to request a same-day booking by room ID and name.'],['Database administrator','Create the schema and connection configuration; the application can initialize timetable data from bundled SQL when its checks fail.']],[39*mm,117*mm],caption='Table 1.1. Current users and system interactions.')

# Chapter 2
H('CHAPTER 2: REQUIREMENTS AND FEASIBILITY',0)
H('2.1 Functional requirements',1)
tbl([['ID','Requirement','Current status'],['FR-01','Connect to MySQL using JDBC configuration.','Implemented'],['FR-02','Initialize/check expected schema and timetable row count.','Implemented'],['FR-03','List all campus rooms.','Implemented'],['FR-04','Find free rooms for a weekday and time.','Implemented'],['FR-05','Find timetable classes overlapping a time range.','Implemented'],['FR-06','Create a same-day booking for a room free now.','Implemented in console'],['FR-07','Create, view, update, and delete every main entity.','Not complete'],['FR-08','Authenticate users and apply role-based permissions.','Not implemented']],[15*mm,91*mm,50*mm],font=7.5,caption='Table 2.1. Functional requirements traceability.')
H('2.2 Non-functional requirements',1)
bullets(['Usability: provide a small Swing window with day/time selectors and readable room status.','Data integrity: use primary keys, foreign keys, and time-range CHECK constraints.','Database safety: use PreparedStatement parameters for data values.','Maintainability: keep database queries together in TimetableDao, while noting that all classes currently share one source file.','Portability: Java 17 source compatibility is configured in Maven; local verification used JDK 21.'])
H('2.3 Hardware and software requirements',1)
tbl([['Component','Requirement / project configuration'],['Runtime','Java 17 or newer (verified local runtime: JDK 21.0.9).'],['Database','MySQL Server 8.x; schema database name roomwise_db.'],['Connectivity','MySQL Connector/J 8.3.0 through JDBC.'],['Build','Maven project definition in pom.xml; local launch can use javac and the Connector/J jar.'],['Interface','Java Swing GUI and a console menu.'],['Configuration','RoomWise/db.properties at the project root; do not publish credentials.']],[40*mm,116*mm],caption='Table 2.2. Hardware and software requirements.')
H('2.4 Feasibility',1)
P('<b>Technical:</b> Feasible on a Java and MySQL workstation; this was verified by launching the current application against the local database. <b>Operational:</b> The interface is small and requires only a running MySQL service and configured credentials. <b>Economic:</b> The implementation uses Java and MySQL components and does not require a paid hosted service. <b>Schedule:</b> The core browsing workflow exists; completing the assignment-level OOP model and full CRUD remains additional work.')
H('2.5 Assumptions and constraints',1)
bullets(['Timetable entries repeat weekly and are selected by day of week.','Bookings are stored for a calendar date and checked against that date plus the recurring weekday timetable.','A booking begins at the current local time when using the console booking flow and ends before the next occupation time returned for the room.','The current schema is the three-table schema in RoomWise/schema.sql; earlier designs described in project notes are not part of this current implementation.'])

# Chapter 3
H('CHAPTER 3: SYSTEM ANALYSIS AND DESIGN',0)
H('3.1 System overview',1)
P('RoomWise has three practical layers in its execution path: a Swing or console interface, a TimetableDao that performs query and insert operations, and the MySQL database. DatabaseConnection reads db.properties and opens JDBC connections. DatabaseInitializer checks the expected schema and row count and can load schema.sql and real_data.sql when the local database requires initialization.')
class Architecture(Flowable):
 def __init__(self,w=155*mm,h=45*mm): Flowable.__init__(self); self.width=w; self.height=h
 def draw(self):
  c=self.canv
  boxes=[(0,18,42,18,'Swing UI / Console',BLUE),(56,18,42,18,'TimetableDao',TEAL),(112,18,42,18,'MySQL',NAVY)]
  for x,y,w,h,label,col in boxes:
   c.setFillColor(col); c.roundRect(x*mm,y*mm,w*mm,h*mm,3*mm,fill=1,stroke=0); c.setFillColor(colors.white); c.setFont('Arial-Bold',8); c.drawCentredString((x+w/2)*mm,(y+7)*mm,label)
  c.setStrokeColor(MUTED); c.setLineWidth(1.3)
  for x1,x2 in [(42,56),(98,112)]:
   c.line(x1*mm,27*mm,x2*mm,27*mm); c.line((x2-2)*mm,29*mm,x2*mm,27*mm); c.line((x2-2)*mm,25*mm,x2*mm,27*mm)
  c.setFont('Arial',7); c.setFillColor(MUTED); c.drawCentredString(49*mm,13*mm,'JDBC calls'); c.drawCentredString(105*mm,13*mm,'SQL / rows')
story.append(Architecture()); story.append(Paragraph('Figure 3.1. Current application data path.',styles['Caption']))
H('3.2 Availability search logic',1)
P('For a selected weekday and time, a room is excluded if a timetable slot contains that time or a booking for the selected date contains that time. A room is considered occupied at time t when start_time is less than or equal to t and end_time is greater than t. The query also finds the next timetable or booking start time so the interface can show when the room becomes occupied.')
H('3.3 Interval overlap rule',1)
P('For a requested interval [requestStart, requestEnd) and an existing interval [existingStart, existingEnd), the SQL overlap predicate is: <font name="Courier">existingStart &lt; requestEnd AND existingEnd &gt; requestStart</font>. This permits back-to-back intervals where one booking ends exactly as another begins.')
H('3.4 Booking workflow',1)
bullets(['The console lists rooms free at the current time.','The teacher selects a room ID and enters a name and end time.','The application checks that the end is after the current time and does not pass the room next occupation.','TimetableDao opens a JDBC connection and disables auto-commit.','PreparedStatements count timetable and dated-booking overlaps for the selected room.','If a conflict exists, the transaction is rolled back and an error is shown. Otherwise, the booking is inserted and committed.'])
H('3.5 OOP concept mapping in the current code',1)
tbl([['Concept','Evidence in current implementation','Status against assignment'],['Encapsulation','Java records Room, OccupiedSlot, FreeRoom, ClassDetails store immutable components; Swing view state is private.','Partial; no validated setters/model hierarchy.'],['Inheritance','RoomFinderWindow extends JFrame; DatabaseException extends RuntimeException; JTable model uses an anonymous DefaultTableModel subclass.','Library/framework inheritance exists; domain hierarchy is absent.'],['Polymorphism','The table model overrides isCellEditable, which JTable calls through the table-model type.','Framework-level override; domain polymorphism is absent.'],['Abstraction','TimetableDao and DatabaseConnection centralize responsibilities, but no domain abstract class or application DAO interface exists.','Partial.'],['Exception handling','DatabaseException wraps SQL/IO errors; try-with-resources closes JDBC resources; UI catches runtime/input errors.','Implemented at basic level.'],['Packages','All Java classes are declared in package roomwise in one source file.','Package usage exists; layered packages are absent.']],[29*mm,75*mm,52*mm],font=7.2,caption='Table 3.1. OOP concept mapping in the current code.')

# Chapter 4
H('CHAPTER 4: DATABASE DESIGN',0)
H('4.1 Database overview',1)
P('The current MySQL schema has three tables: rooms, timetable_slots, and bookings. Rooms are the parent entity. Timetable slots refer to rooms with ON DELETE CASCADE. Bookings refer to rooms with ON DELETE RESTRICT. Primary keys are auto-incrementing integer IDs. Timetable and booking ranges have CHECK constraints requiring end_time to be later than start_time.')
class ERDiagram(Flowable):
 def __init__(self,w=156*mm,h=79*mm): Flowable.__init__(self); self.width=w; self.height=h
 def draw(self):
  c=self.canv
  def box(x,y,w,h,title,fields):
   c.setFillColor(PALE); c.setStrokeColor(BLUE); c.roundRect(x*mm,y*mm,w*mm,h*mm,2*mm,fill=1,stroke=1)
   c.setFillColor(NAVY); c.rect(x*mm,(y+h-8)*mm,w*mm,8*mm,fill=1,stroke=0); c.setFillColor(colors.white); c.setFont('Arial-Bold',8); c.drawString((x+3)*mm,(y+h-5.5)*mm,title)
   c.setFillColor(INK); c.setFont('Courier',6.5)
   for i,f in enumerate(fields): c.drawString((x+3)*mm,(y+h-13-i*6)*mm,f)
  box(2,46,42,26,'rooms',['PK id INT','room VARCHAR(40)'])
  box(57,47,49,32,'timetable_slots',['PK id INT','FK room_id INT','day_of_week ENUM','start_time, end_time TIME','course_code, course_name','section, teacher, class_type'])
  box(116,47,39,32,'bookings',['PK id INT','FK room_id INT','teacher VARCHAR(150)','booking_date DATE','start_time, end_time TIME'])
  c.setStrokeColor(MUTED); c.setLineWidth(1); c.line(44*mm,58*mm,57*mm,58*mm); c.line(106*mm,58*mm,116*mm,58*mm)
  c.setFont('Arial',6.5); c.setFillColor(MUTED); c.drawString(45*mm,61*mm,'1 to many'); c.drawString(106.5*mm,61*mm,'1 to many')
  c.setFillColor(TEAL); c.roundRect(3*mm,5*mm,149*mm,26*mm,2*mm,fill=1,stroke=0)
  c.setFillColor(colors.white); c.setFont('Arial-Bold',8); c.drawString(6*mm,26*mm,'Indexes and integrity')
  c.setFont('Arial',7); c.drawString(6*mm,20*mm,'rooms.id: primary key; rooms.room: unique'); c.drawString(6*mm,15*mm,'timetable_slots.room_id -> rooms.id (cascade); bookings.room_id -> rooms.id (restrict)')
  c.drawString(6*mm,10*mm,'Indexes support weekday/room/time and date/room/time lookups.')
story.append(ERDiagram()); story.append(Paragraph('Figure 4.1. Entity relationship view of the implemented schema.',styles['Caption']))
H('4.2 Table descriptions',1)
tbl([['Table','Important columns','Purpose'],['rooms','id (PK), room (unique)','Stores each distinct campus room label.'],['timetable_slots','id (PK), room_id (FK), day_of_week, start_time, end_time, course_code, course_name, section, teacher, class_type','Stores recurring weekly theory and lab periods.'],['bookings','id (PK), teacher, room_id (FK), booking_date, start_time, end_time','Stores dated room reservations created by the console booking flow.']],[33*mm,78*mm,45*mm],font=7.4,caption='Table 4.1. Database tables and important columns.')
H('4.3 Referential and domain constraints',1)
bullets(['rooms.room has a UNIQUE constraint, preventing duplicate room labels.','timetable_slots.room_id references rooms.id and cascades when a room is deleted.','bookings.room_id references rooms.id and restricts deletion of a room with bookings.','The day_of_week and class_type columns use enumerated values.','Both timetable_slots and bookings require end_time > start_time.','Indexes are created on timetable_slots(day_of_week, room_id, start_time, end_time) and bookings(booking_date, room_id, start_time, end_time).'])
H('4.4 Data volume and source',1)
P('The bundled real_data.sql script describes 4,167 timetable records derived from the supplied theory and lab JSON exports. The database initializer verifies that timetable row count and expected columns match its startup assumptions. During live verification on 9 November 2026, the application queried the local MySQL database for Monday at 9:00 and displayed 91 free-room results and 77 occupied-class results.')
H('4.5 Design limitations',1)
P('The current database does not include users, roles, buildings, equipment, course entities, or an audit log. Course and instructor information is repeated in timetable_slots. These are conscious facts of the actual schema, not omitted descriptions of tables that do not exist. Normalization and user identity should be revisited if the project expands to administration or authenticated bookings.')

# Chapter 5
H('CHAPTER 5: IMPLEMENTATION',0)
H('5.1 Technology stack',1)
tbl([['Area','Implementation'],['Language','Java; Maven compiler source/target set to 17.'],['Interface','Swing RoomFinderWindow and terminal ConsoleMenu.'],['Database','MySQL, database roomwise_db.'],['Connectivity','JDBC through MySQL Connector/J 8.3.0.'],['Query style','PreparedStatement for all runtime SQL parameters.'],['Configuration','db.properties at the project root, loaded from the classpath.'],['Source organization','Single source file RoomWise/main/Main.java, package roomwise.']],[39*mm,117*mm],caption='Table 5.1. Technology stack.')
H('5.2 Startup and database setup',1)
P('Main.main invokes DatabaseInitializer.initialize(), constructs TimetableDao, and verifies the schema. The initializer opens a connection, obtains a named MySQL advisory lock, checks the expected columns and timetable record count, then loads schema.sql and real_data.sql if the checks indicate an uninitialized or inconsistent database. Connection settings are read from db.properties. The project includes a db.properties.example template; actual credentials must remain local and must not appear in a submitted public repository.')
H('5.3 Data access and JDBC',1)
P('TimetableDao contains the application SQL. Read operations use SELECT queries and map ResultSet columns into Java records. The free-room query uses correlated subqueries and NOT EXISTS checks against timetable slots and bookings. The class search query joins timetable_slots to rooms and applies an overlap predicate. Room IDs, days, times, and dates are supplied using PreparedStatement setter methods.')
H('5.4 User interface',1)
P('The Swing interface provides a day selector, a time selector, and Free and Occupied buttons. Results appear in a non-editable JTable with room, status, and detail columns. The console interface adds options to list all rooms, make a same-day booking, and search classes by interval. The Swing interface itself does not expose booking creation.')
H('5.5 Booking insert and transaction',1)
P('The console booking action validates user-entered name and time, then calls TimetableDao.book. That method disables auto-commit, checks for overlapping timetable and booking rows, rolls back on detected conflicts, inserts the booking with a prepared statement, and commits on success. This protects against a conflict observed by the transaction. The current method does not lock the selected room row or enforce a database exclusion/uniqueness constraint for overlapping intervals, so two simultaneous booking requests could still race; robust concurrent booking prevention remains future work.')
H('5.6 Implemented operations',1)
tbl([['Entity / data','Create','Read','Update','Delete'],['Rooms','No UI operation','List all rooms; use in searches','No','No'],['Timetable slots','Loaded by SQL initialization','Availability and class queries','No','Initialization script replaces data'],['Bookings','Console insert','Used by availability/conflict checks; no booking list screen','No','No application cancellation']],[30*mm,28*mm,43*mm,27*mm,28*mm],font=7.3,caption='Table 5.2. Implemented database operations.')
P('The project therefore demonstrates database reads and a booking create operation, but not full end-to-end CRUD for each principal entity. The table above is the actual application scope, not the broader assignment checklist.')

# Chapter 6
H('CHAPTER 6: VERIFICATION AND TEST PLAN',0)
H('6.1 Verification performed for this report',1)
tbl([['Check','Result','Evidence / scope'],['Compile current Java source','Passed','JDK 21 javac compiled Main.java into a temporary output folder.'],['Database connection','Passed','TimetableDao verified the expected MySQL schema.'],['Free-room results','Observed','Monday at 9:00: 91 free-room rows displayed.'],['Occupied-class results','Observed','Monday at 9:00: 77 occupied-class rows displayed.'],['Automated test suite','Not run','No automated suite was run for this report preparation.']],[40*mm,28*mm,88*mm],font=7.2,caption='Table 6.1. Verification performed during report preparation.')
H('6.2 Manual functional test cases',1)
tbl([['Test ID','Action','Expected result'],['TC-01','Start MySQL, configure db.properties, launch application.','Database initializes or validates, then UI opens.'],['TC-02','Choose weekday/time and press Free.','Rooms with no active timetable or booking at that instant appear.'],['TC-03','Choose weekday/time and press Occupied.','Classes whose time intervals include the selected instant appear.'],['TC-04','Search a range where a class overlaps.','Matching rows include room, course, section, teacher, and class times.'],['TC-05','Attempt a booking overlapping a timetable slot.','Booking is rejected and no insert is committed.'],['TC-06','Book an available room until before its next scheduled class.','Booking record is inserted and committed.'],['TC-07','Enter an invalid end time or room ID.','Input is rejected with a user-facing message.'],['TC-08','Stop MySQL or use invalid connection settings.','DatabaseException is reported; the application does not continue normally.']],[16*mm,78*mm,62*mm],font=7.2,caption='Table 6.2. Manual functional test cases.')
H('6.3 Important edge cases for future automated tests',1)
bullets(['Adjacent intervals: booking end equals the next class start; should be allowed.','Partial overlap at either end of an existing class or booking; should be rejected.','A request fully containing an existing interval; should be rejected.','An empty room schedule on a weekday; should remain available until the end of day unless a dated booking exists.','A booking whose end equals its start; rejected by application validation and the database CHECK.','Two simultaneous attempts for the same room and overlapping period; concurrency safety needs a database-level lock or constraint.'])
H('6.4 Verification limits',1)
P('The live checks above demonstrate source compilation, database startup, and visible GUI output on the local machine. They do not establish correctness under all datasets, concurrent load, operating systems, or database versions. The report does not claim a completed automated test suite.')

# Chapter 7
H('CHAPTER 7: SECURITY, LIMITATIONS, AND MAINTENANCE',0)
H('7.1 Security practices present',1)
bullets(['Runtime SQL values use PreparedStatement parameters, reducing SQL injection risk for the entered values.','Database credentials are separated into a local db.properties file and an example template.','JDBC connections, statements, and result sets use try-with-resources in the main DAO methods.','The booking workflow checks conflicts before inserting; however, simultaneous requests require stronger database locking.'])
H('7.2 Security gaps',1)
bullets(['There is no login, identity verification, role authorization, or teacher account table. The booking teacher value is free text.','The supplied connection URL uses local MySQL settings and does not establish a production TLS or secret-management policy.','The UI does not audit who viewed or changed data.','The SQL initializer can drop and rebuild application tables when its schema checks fail; database backup and migration handling should be added before production use.'])
H('7.3 Current limitations',1)
bullets(['No full CRUD screens or DAO methods for every entity; bookings cannot be updated or cancelled through the application.','No admin interface, user roles, room metadata filters, capacity/equipment data, or utilization reports.','OOP concepts required by the project rubric are only partially demonstrated: there is no model inheritance hierarchy, DAO interface layer, domain polymorphism, or multiple packages.','The booking transaction does not serialize concurrent requests for the same room.','The timetable is queried as a recurring weekly schedule; exceptions, holidays, and one-off timetable changes are not modeled.','The GUI provides availability and occupied views; booking is available only from the console.'])
H('7.4 Maintenance recommendations',1)
bullets(['Back up roomwise_db before running schema or timetable reload scripts.','Keep db.properties out of version control and rotate any credential that was accidentally shared.','Use schema migration scripts rather than destructive table rebuilds as the database evolves.','Add validation and automated tests for time overlap, day/date conversion, and simultaneous booking.','Separate model, DAO, service, UI, exception, and utility packages so each OOP and DBMS responsibility is easy to demonstrate.','Add booking search, update, cancellation, and an audit trail; then verify foreign-key and conflict rules.'])

# Chapter 8
H('CHAPTER 8: CONCLUSION AND FUTURE WORK',0)
H('8.1 Conclusion',1)
P('RoomWise demonstrates a working connection between a Java application and a MySQL database for campus timetable browsing. It imports a realistic schedule, queries free and occupied rooms, and offers a basic transactional booking insert through the console. The Swing view makes the timetable results accessible, while PreparedStatements, primary and foreign keys, indexes, CHECK constraints, and JDBC resource handling provide concrete DBMS implementation examples.')
P('The current implementation is a functional foundation rather than a complete match for every assignment requirement. It does not yet provide full CRUD, role-based access, or a comprehensive object-oriented domain model. The report identifies these gaps so the team can present the working system accurately and prioritize remaining work.')
H('8.2 Future work',1)
bullets(['Create domain classes and interfaces demonstrating abstraction, inheritance, runtime polymorphism, encapsulation, and checked exceptions.','Add separate packages for model, DAO, service, UI, exception, and utility responsibilities.','Implement full CRUD for rooms, timetable entries, and bookings with prepared SQL and service validation.','Add database-level concurrency control for reservations, including room-row locking or a robust conflict constraint strategy.','Add users, roles, authentication, and audit logging.','Add filters for room capacity, type, equipment, and purpose after extending the schema.','Add holiday and exceptional timetable support, booking cancellation, and utilization reports.','Add a reproducible automated test suite and capture the team\'s final run screenshots for Appendix B.'])

# References
H('REFERENCES',0)
for ref in [
'[1] RoomWise project source, main/Main.java. Java application entry point, Swing interface, JDBC DAO, console booking flow, database initialization, and connection helper.',
'[2] RoomWise project schema, schema.sql. MySQL table definitions, keys, constraints, and indexes.',
'[3] RoomWise timetable load script, real_data.sql. Bundled timetable seed data generated from theory and laboratory exports.',
'[4] RoomWise project configuration, pom.xml. Java compiler settings, MySQL Connector/J dependency, and JUnit dependency declaration.',
'[5] MySQL Connector/J 8.3.0, JDBC driver dependency configured in pom.xml.',
'[6] Supplied theory and lab timetable data files, RoomWise/data/theory.json and RoomWise/data/labs.json.',
'[7] NAMMA CHENNAI: An Integrated Transport and Tourism Management System, OOP using Java and DBMS Project Report, supplied as a formatting reference. Its project details and implementation claims are not reused.'
]: P(ref)
P('Before final submission, update the institution, course, student, guide, academic-year, and access-date information to match the team records.','Small')

# Appendix A
H('APPENDIX A: SQL SCHEMA',0)
P('The following schema is transcribed from the current RoomWise/schema.sql. This is the implemented three-table schema. Run it only when it is appropriate to initialize or rebuild the local project database.')
schema='''CREATE DATABASE IF NOT EXISTS roomwise_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE roomwise_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS timetable_slots;
DROP TABLE IF EXISTS rooms;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE rooms (
    id   INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room VARCHAR(40) NOT NULL UNIQUE
);

CREATE TABLE timetable_slots (
    id          INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    room_id     INT          NOT NULL,
    day_of_week ENUM('MONDAY','TUESDAY','WEDNESDAY','THURSDAY',
                     'FRIDAY','SATURDAY','SUNDAY') NOT NULL,
    start_time  TIME         NOT NULL,
    end_time    TIME         NOT NULL,
    course_code VARCHAR(40)  NOT NULL,
    course_name VARCHAR(180) NOT NULL,
    section     VARCHAR(180) NOT NULL,
    teacher     VARCHAR(150) NOT NULL,
    class_type  ENUM('THEORY','LAB') NOT NULL,
    CONSTRAINT chk_slot_times CHECK (end_time > start_time),
    CONSTRAINT fk_slot_room FOREIGN KEY (room_id) REFERENCES rooms(id)
        ON DELETE CASCADE
);

CREATE TABLE bookings (
    id           INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    teacher      VARCHAR(150) NOT NULL,
    room_id      INT          NOT NULL,
    booking_date DATE         NOT NULL,
    start_time   TIME         NOT NULL,
    end_time     TIME         NOT NULL,
    CONSTRAINT chk_booking_times CHECK (end_time > start_time),
    CONSTRAINT fk_booking_room FOREIGN KEY (room_id) REFERENCES rooms(id)
        ON DELETE RESTRICT
);

CREATE INDEX idx_slots_day_room_time
    ON timetable_slots(day_of_week, room_id, start_time, end_time);
CREATE INDEX idx_bookings_date_room_time
    ON bookings(booking_date, room_id, start_time, end_time);'''
story.append(Preformatted(schema,styles['Code']))

# Appendix B output screenshots
H('APPENDIX B: OUTPUT SCREENSHOTS',0)
P('The following captures show the RoomWise Swing interface connected to the local MySQL database. The day selector is set to Monday and the time selector to 9:00. Figure B.1 shows free-room results; Figure B.2 shows occupied-class results. The output reflects the database records available during capture on 9 November 2026.')
class Placeholder(Flowable):
 def __init__(self,title,detail,w=155*mm,h=62*mm): Flowable.__init__(self); self.width=w; self.height=h; self.title=title; self.detail=detail
 def draw(self):
  c=self.canv; c.setFillColor(HexColor('#F8FAFB')); c.setStrokeColor(HexColor('#93AAB8')); c.setDash(4,3); c.roundRect(0,0,self.width,self.height,3*mm,fill=1,stroke=1); c.setDash()
  c.setFillColor(BLUE); c.setFont('Arial-Bold',10); c.drawCentredString(self.width/2,self.height/2+5*mm,self.title)
  c.setFillColor(MUTED); c.setFont('Arial',8); c.drawCentredString(self.width/2,self.height/2-2*mm,self.detail)
  c.setFont('Arial',7); c.drawCentredString(self.width/2,7*mm,'Replace this box with a genuine capture from the running RoomWise application.')
story.append(Spacer(1,3*mm)); story.append(RLImage('tmp/roomwise_free.png',width=160*mm,height=160*560/900*mm,hAlign='CENTER'))
story.append(Spacer(1,3)); story.append(Paragraph('Figure B.1. Free-room search results for Monday at 9:00.',styles['Caption']))
story.append(PageBreak())
H('APPENDIX B: OUTPUT SCREENSHOTS / CONTINUED',0)
story.append(RLImage('tmp/roomwise_occupied.png',width=160*mm,height=160*560/900*mm,hAlign='CENTER'))
story.append(Spacer(1,3)); story.append(Paragraph('Figure B.2. Occupied-class search results for Monday at 9:00.',styles['Caption']))

os.makedirs(os.path.dirname(OUT),exist_ok=True)
doc=ReportDoc(OUT,pagesize=A4,rightMargin=22*mm,leftMargin=22*mm,topMargin=20*mm,bottomMargin=21*mm,title='RoomWise Final Project Report',author='RoomWise Project Team')
doc.multiBuild(story)
print(OUT)
