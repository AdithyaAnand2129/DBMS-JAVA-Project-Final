from pypdf import PdfReader
from pathlib import Path

reader=PdfReader(r'C:\Users\adith\Downloads\NAMMA_CHENNAI.pdf')
out=Path('tmp/rec_logo.png')
for image in reader.pages[0].images:
    if image.name=='Im4.png':
        image.image.save(out)
        print(out, image.image.size)
        break
else:
    print('target image not found')
