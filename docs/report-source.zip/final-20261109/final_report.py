from pathlib import Path
import sys
from xml.sax.saxutils import escape
import textwrap, hashlib, json
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, NextPageTemplate, Table, TableStyle, Image as RImage, Flowable, Preformatted, KeepTogether
from reportlab.platypus.tableofcontents import TableOfContents

ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(r'D:/Pen drive 250 gb/Project - COLLEGE/RoomWise')
WORK=Path(__file__).parent
OUT=ROOT/'docs/RoomWise_Final_Project_Report.pdf'
SRC=ROOT/'src/main/java/roomwise'
W,H=A4; CW=W-48*mm
for name,file in [('TimesNew','times.ttf'),('TimesNew-Bold','timesbd.ttf'),('TimesNew-Italic','timesi.ttf'),('Arial','arial.ttf'),('Arial-Bold','arialbd.ttf'),('Consolas','consola.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'C:/Windows/Fonts/'+file))
pdfmetrics.registerFontFamily('TimesNew',normal='TimesNew',bold='TimesNew-Bold',italic='TimesNew-Italic',boldItalic='TimesNew-Bold')
S={}
S['body']=ParagraphStyle('body',fontName='TimesNew',fontSize=11.3,leading=16.8,spaceAfter=9,alignment=TA_JUSTIFY)
S['h1']=ParagraphStyle('h1',fontName='TimesNew-Bold',fontSize=17,leading=23,spaceAfter=18,alignment=TA_CENTER,keepWithNext=True)
S['h2']=ParagraphStyle('h2',fontName='TimesNew-Bold',fontSize=12.5,leading=17,spaceBefore=10,spaceAfter=7,keepWithNext=True)
S['caption']=ParagraphStyle('caption',fontName='TimesNew-Italic',fontSize=9.5,leading=13,spaceBefore=7,spaceAfter=12,alignment=TA_CENTER)
S['small']=ParagraphStyle('small',fontName='TimesNew',fontSize=9.5,leading=13.5,spaceAfter=8)
S['center']=ParagraphStyle('center',parent=S['body'],alignment=TA_CENTER)
S['code']=ParagraphStyle('code',fontName='Consolas',fontSize=8.5,leading=12,spaceAfter=9)
S['kicker']=ParagraphStyle('kicker',fontName='Arial',fontSize=8,leading=12,textColor=colors.HexColor('#666666'),spaceAfter=10)
story=[]
class Index(TableOfContents):
    def __init__(self,kind):
        super().__init__(); self.kind=kind
        self.levelStyles=[ParagraphStyle('idx'+kind,fontName='TimesNew',fontSize=10,leading=14,spaceBefore=4)]
    def notify(self,kind,stuff):
        if kind==self.kind: self.addEntry(*stuff)
class Doc(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A4,title='RoomWise - OOP using Java and DBMS Project Report',author='Adithya Narayana Anand; Aadithya T; Mitran Reddy')
        normal=Frame(24*mm,20*mm,CW,H-43*mm,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
        lw,lh=landscape(A4)
        wide=Frame(18*mm,16*mm,lw-36*mm,lh-36*mm,id='wide',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
        self.addPageTemplates([PageTemplate('cover',[normal],onPage=self.decorate),PageTemplate('body',[normal],onPage=self.decorate),PageTemplate('wide',[wide],pagesize=landscape(A4),onPage=self.decorate)])
        self.seq=0
    def beforeDocument(self): self.seq=0
    def decorate(self,c,d):
        w,h=c._pagesize
        if d.page==1:
            c.setStrokeColor(colors.HexColor('#C8C0D6'));c.setLineWidth(.5);c.rect(9*mm,9*mm,w-18*mm,h-18*mm)
        if d.page>=5:
            c.setFont('Arial-Bold',8); c.drawString(24*mm,h-14*mm,'ROOMWISE PROJECT REPORT');c.setFont('TimesNew',9);c.drawRightString(w-24*mm,h-14*mm,str(d.page))
            c.setStrokeColor(colors.HexColor('#BBBBBB'));c.line(24*mm,h-17*mm,w-24*mm,h-17*mm)
    def afterFlowable(self,f):
        if hasattr(f,'entry'):
            self.seq+=1; kind,level=f.entry; text=f.getPlainText(); key='item'+str(self.seq)
            self.canv.bookmarkPage(key)
            self.notify(kind,(level,text,self.page,key))
            if kind=='TOCEntry' and level==0: self.canv.addOutlineEntry(text,key,0,False)
def p(text,style='body'): story.append(Paragraph(text,S[style]))
def heading(text,level=0,toc=True):
    f=Paragraph(text,S['h1' if level==0 else 'h2'])
    if toc: f.entry=('TOCEntry',level)
    story.append(f)
def new(title=None,chapter=None):
    story.append(PageBreak())
    if chapter: p(chapter.upper()+' / CONTINUED','kicker')
    if title: heading(title,0 if not chapter else 1)
def cap(text,kind='FigureEntry'):
    f=Paragraph(text,S['caption']);f.entry=(kind,0);story.append(f)
def table(rows,widths=None,caption=None,size=9.3):
    st=ParagraphStyle('cell',fontName='TimesNew',fontSize=size,leading=size+3)
    hd=ParagraphStyle('cellhead',parent=st,fontName='TimesNew-Bold')
    cells=[[Paragraph(escape(str(v)),hd if i==0 else st) for v in row] for i,row in enumerate(rows)]
    if widths: widths=[CW*x/sum(widths) for x in widths]
    t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#AAAAAA')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#EEEEEE')),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7)]))
    story.append(t)
    if caption: cap(caption,'TableEntry')
def code(text):
    lines=[]
    for line in text.splitlines(): lines.extend(textwrap.wrap(line,86,replace_whitespace=False,drop_whitespace=False) or [''])
    story.append(Preformatted('\n'.join(lines),S['code']))
def img(path,maxwidth=CW,maxheight=460):
    im=Image.open(path); scale=min(maxwidth/im.width,maxheight/im.height);story.append(RImage(str(path),width=im.width*scale,height=im.height*scale))
def source_image(name,start,end,slug):
    lines=(SRC/name).read_text().splitlines(); selected=lines[start-1:end]
    font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',20)
    rows=[]
    for n,line in enumerate(selected,start):
        chunks=textwrap.wrap(line,92,replace_whitespace=False,drop_whitespace=False) or ['']
        rows += [(f'{n:3}' if i==0 else '  >',chunk) for i,chunk in enumerate(chunks)]
    width=1220;height=82+29*len(rows)
    im=Image.new('RGB',(width,height),'#FAFAFA');draw=ImageDraw.Draw(im)
    draw.rectangle((0,0,width,45),fill='#E8E8E8');draw.text((20,10),name,font=font,fill='#222222')
    for i,(n,line) in enumerate(rows):
        draw.text((10,62+i*29),n,font=font,fill='#777777');draw.text((62,62+i*29),line,font=font,fill='#173257' if not line.lstrip().startswith(('/','*')) else '#426340')
    path=WORK/(slug+'.png');im.save(path);return path
def excerpt(name,start,end,slug,caption):
    end=min(end,len((SRC/name).read_text().splitlines()))
    img(source_image(name,start,end,slug),maxheight=430);cap(caption)
    p(f'Source: <font face="Consolas" size="8.5">src/main/java/roomwise/{escape(name)}</font>, lines {start}-{end}. This code image is rendered directly from the submitted source; long lines wrap at the continuation marker.','small')
class Diagram(Flowable):
    def __init__(self,kind,height): super().__init__();self.width=CW;self.height=height;self.kind=kind
    def draw(self):
        c=self.canv
        def box(x,y,w,h,title,lines=()):
            c.setStrokeColor(colors.HexColor('#555555'));c.setFillColor(colors.white);c.rect(x,y,w,h,stroke=1,fill=1)
            c.setFillColor(colors.HexColor('#EEEEEE'));c.rect(x,y+h-25,w,25,stroke=0,fill=1);c.setFillColor(colors.black);c.setFont('TimesNew-Bold',10);c.drawCentredString(x+w/2,y+h-17,title)
            c.setFont('TimesNew',9)
            for i,line in enumerate(lines): c.drawString(x+8,y+h-40-i*14,line)
        def arrow(x1,y1,x2,y2,label=None):
            c.setStrokeColor(colors.black);c.line(x1,y1,x2,y2)
            import math
            a=math.atan2(y2-y1,x2-x1);l=6
            for delta in [-.5,.5]:c.line(x2,y2,x2-l*math.cos(a+delta),y2-l*math.sin(a+delta))
            if label:c.setFont('TimesNew-Italic',8);c.drawString((x1+x2)/2+5,(y1+y2)/2+3,label)
        if self.kind=='architecture':
            box(85,290,290,52,'Swing / Console UI',['Forms, input parsing and result presentation'])
            box(85,205,290,52,'CampusService',['Search overloads, model operations, event dispatch'])
            box(85,120,290,52,'CampusDao interface -> JdbcCampusDao',['Prepared statements, row mapping, atomic writes'])
            box(85,35,290,52,'MySQL / InnoDB',['rooms | timetable_slots | bookings | schedule_guard'])
            arrow(230,290,230,257,'calls');arrow(230,205,230,172,'delegates');arrow(230,120,230,87,'JDBC')
        elif self.kind=='classes':
            box(108,235,244,112,'<<abstract>> ScheduledEvent',['- id, roomId, teacher, start, end','+ overlaps(from, until)','+ occursOn(date): abstract','+ description(): abstract'])
            box(0,75,219,119,'Booking extends ScheduledEvent',['- date: LocalDate','+ date()','+ occursOn(date): exact date','+ description(): booking label'])
            box(242,75,219,119,'TimetableSlot extends ScheduledEvent',['- day, courseCode, courseName','- section, type','+ occursOn(date): weekday','+ description(): class label'])
            arrow(110,194,172,235,'inherits');arrow(350,194,292,235,'inherits')
            c.setFont('TimesNew',10);c.drawCentredString(230,35,'CampusService uses List<ScheduledEvent> for both concrete subclasses.')
        elif self.kind=='er':
            box(136,335,190,75,'rooms',['PK id','UQ room'])
            box(0,100,219,177,'timetable_slots',['PK id','FK room_id -> rooms.id','day_of_week, start_time, end_time','course_code, course_name','section, teacher, class_type','CHECK end_time > start_time','ON DELETE RESTRICT'])
            box(242,100,219,177,'bookings',['PK id','FK room_id -> rooms.id','teacher, booking_date','start_time, end_time','CHECK end_time > start_time','ON DELETE RESTRICT'])
            arrow(180,335,110,277,'1 to 0..*');arrow(282,335,351,277,'1 to 0..*')
            box(136,0,190,65,'schedule_guard',['PK id = 1 (one internal mutex row)'])
        elif self.kind=='flow':
            labels=['Validate model and input','Begin READ COMMITTED transaction','Lock schedule_guard row FOR UPDATE','Check room and teacher overlaps','INSERT / UPDATE / DELETE','Commit; return ID / refresh view']
            for i,label in enumerate(labels):
                y=330-i*60;box(55,y,350,38,label)
                if i<5:arrow(230,y,230,y-22)
            c.setFont('TimesNew-Italic',9);c.drawCentredString(230,0,'Any validation, conflict or SQL failure -> rollback; show an actionable error.')
        elif self.kind=='usecase':
            box(128,30,325,285,'RoomWise application boundary')
            c.setFont('TimesNew-Bold',10);c.drawString(2,260,'Campus user');c.drawString(2,100,'Operator')
            cases=[('Find free rooms',245),('View occupied events',205),('Maintain rooms',145),('Maintain bookings',105),('Maintain timetable',65)]
            for label,y in cases:
                c.ellipse(190,y-15,420,y+15);c.setFont('TimesNew',10);c.drawCentredString(305,y-3,label)
                c.line(85,260 if y>180 else 100,190,y)
            c.setFont('TimesNew-Italic',9);c.drawString(4,5,'Actors describe usage responsibilities; authentication and role enforcement are not implemented.')

# Preliminary pages closely follow the supplied reference's alignment and spacing.
story.append(Spacer(1,25*mm))
story.append(Paragraph('ROOMWISE',ParagraphStyle('coverTitle',fontName='TimesNew-Bold',fontSize=32,leading=40,alignment=TA_CENTER,spaceAfter=18)))
p('Smart Campus Room Finder and Scheduling System','center');story.append(Spacer(1,8*mm))
p('<b>OOP using Java and DBMS Project Report</b>','center');story.append(Spacer(1,17*mm))
p('Report submitted by','center')
for name in ['Adithya Narayana Anand (250701022)','Aadithya T (250701001)','Mitran Reddy (250701422)']:p('<b>'+name+'</b>','center')
story.append(Spacer(1,12*mm));p('Bachelor of Engineering in Computer Science and Engineering','center');p('Semester III | 2026','center')
story.append(Spacer(1,10*mm));p('<b>Rajalakshmi Engineering College, Thandalam</b>','center');p('An Autonomous Institution Affiliated to Anna University','center')
img(WORK/'rec_logo_flat.png',maxwidth=62*mm,maxheight=29*mm)
story.append(NextPageTemplate('body'));new()
story.append(Spacer(1,5*mm));img(WORK/'rec_logo_flat.png',maxwidth=64*mm,maxheight=31*mm);story.append(Spacer(1,10*mm))
cert=ParagraphStyle('certificateTitle',fontName='Arial-Bold',fontSize=18,leading=23,alignment=TA_CENTER,spaceAfter=28)
f=Paragraph('BONAFIDE CERTIFICATE',cert);f.entry=('TOCEntry',0);story.append(f)
p('Certified that this is the bonafide record of the project titled <b>"ROOMWISE"</b> done by <b>Adithya Narayana Anand (250701022)</b>, <b>Aadithya T (250701001)</b> and <b>Mitran Reddy (250701422)</b>, who carried out the project work under our supervision during the academic year <b>2026</b>.')
story.append(Spacer(1,27*mm))
sig=Table([[Paragraph('<b>Dr K Ananthajothi</b><br/>Faculty in-charge<br/>OOP using Java<br/>Dept of CSE',S['body']),Paragraph('<b>Ms S Kaviya</b><br/>Faculty in-charge<br/>DBMS<br/>Dept of CSE',S['body'])]],colWidths=[CW*.67,CW*.33]);sig.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0)]));story.append(sig)
story.append(Spacer(1,19*mm));p('Submitted for the Practical Examination held on  __________________')
story.append(Spacer(1,24*mm));story.append(Table([[Paragraph('<b>Internal Examiner</b>',S['body']),Paragraph('<b>External Examiner</b>',S['body'])]],colWidths=[CW*.67,CW*.33]))
new('STUDENT DECLARATION')
p('We, <b>Adithya Narayana Anand (250701022)</b>, <b>Aadithya T (250701001)</b> and <b>Mitran Reddy (250701422)</b>, students of Semester III, Department of Computer Science and Engineering, Rajalakshmi Engineering College, hereby declare that the project report entitled <b>"RoomWise - Smart Campus Room Finder and Scheduling System"</b> records the project submitted for Object-Oriented Programming using Java and Database Management Systems.')
p('The implementation uses Java, Swing, JDBC and MySQL. This report describes the source code and database schema supplied with the project, including the implemented OOP concepts, database operations, verification results and remaining limitations. External technical material and the supplied timetable data are identified in the References section.')
p('We accept responsibility for reviewing the report, understanding the implementation and explaining the project during the practical demonstration and evaluation. Each team member must be able to trace a user action through the service layer to its SQL operation and explain the associated object-oriented concepts.')
p('Place: Chennai<br/>Date: __________________')
story.append(Spacer(1,22*mm))
for name in ['Adithya Narayana Anand (250701022)','Aadithya T (250701001)','Mitran Reddy (250701422)']:
    p('<b>'+name+'</b><br/>Signature: __________________');story.append(Spacer(1,5*mm))
new('ACKNOWLEDGEMENT')
p('We express our sincere gratitude to the management and faculty of Rajalakshmi Engineering College, Thandalam, for providing the opportunity and facilities to undertake this project.')
p('We thank the Department of Computer Science and Engineering for the academic support provided during the development of RoomWise. The project helped us connect classroom concepts in object-oriented programming and relational database management with an application that addresses campus room availability.')
p('We extend our thanks to <b>Dr K Ananthajothi</b>, Faculty in-charge of OOP using Java, for guidance in the study and application of object-oriented programming concepts. We also thank <b>Ms S Kaviya</b>, Faculty in-charge of DBMS, for guidance in database design, SQL and Java database connectivity.')
p('We acknowledge the supplied theory and laboratory timetable datasets used to exercise the application. We also acknowledge the official Java and MySQL documentation consulted while implementing the JDBC connection, SQL constraints and transactions.')
p('We thank our classmates and everyone who contributed suggestions and feedback. The team is responsible for verifying the final submission and preparing for its demonstration.')
story.append(Spacer(1,15*mm))
for name in ['Adithya Narayana Anand','Aadithya T','Mitran Reddy']:p(name,'center')
new('ABSTRACT')
p('RoomWise is a Java desktop and console application that helps users discover free campus rooms and maintain room schedules. A recurring weekly timetable and dated reservations are stored in MySQL and accessed through hand-written JDBC. The supplied dataset contains 157 rooms and 4,167 timetable records, providing a realistic basis for availability searches and database demonstrations.')
p('The application supports Create, Read, Update and Delete operations for rooms, bookings and timetable entries. Users can search availability at a particular time or for an entire interval, inspect occupied events, create reservations, reschedule them and cancel them. A room with dependent schedules cannot be deleted until those dependencies are removed.')
p('The Java implementation demonstrates encapsulation through validated private fields, abstraction through an abstract event class and a persistence interface, inheritance through booking and timetable subclasses, and runtime polymorphism through date matching and event descriptions. Overloaded search methods demonstrate compile-time polymorphism. Separate model, DAO, service, UI, utility and exception packages make the responsibilities visible.')
p('Database integrity is supported by primary keys, foreign keys, unique room names, time-range checks and explicit transactions. A singleton InnoDB guard row serializes scheduling writes so room and teacher conflicts are checked before a write commits. Eighteen automated tests passed, including CRUD, constraint enforcement, rollback, safe initialization and concurrent booking attempts. This report includes implementation diagrams, the exact SQL schema, source-code images, application screenshots and a team demonstration plan.')
p('<b>Keywords:</b> Java; OOP; Swing; JDBC; MySQL; CRUD; room scheduling; transactions; concurrency.')
p('<b>Implementation snapshot:</b> verified on 9 November 2026. The assignment notice stated a deadline of 05/11/26 (5 November 2026); this report does not assert that submission occurred by that date.','small')
new('TABLE OF CONTENTS')
toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc0',fontName='TimesNew-Bold',fontSize=10.7,leading=15,spaceBefore=6),ParagraphStyle('toc1',fontName='TimesNew',fontSize=9.7,leading=13,leftIndent=13,spaceBefore=2)];story.append(toc)
new('LIST OF FIGURES');story.append(Index('FigureEntry'))
new('LIST OF TABLES');story.append(Index('TableEntry'))

new('CHAPTER 1: INTRODUCTION')
heading('1.1 Background and problem statement',1)
p('Campus teaching rooms are shared by multiple departments, sections and teachers. A room may be free for one period yet required by another class shortly afterward. Checking an isolated timetable row is therefore insufficient: a useful room finder must consider the requested date, weekly classes, existing reservations and the whole requested interval.')
p('RoomWise consolidates timetable and booking information into one application. The problem addressed is: given a date and a point or interval in time, identify rooms that have no conflicting event, and maintain the records that determine that result. A second requirement is to prevent a teacher or room from being booked for overlapping events through the application.')
heading('1.2 Project objectives',1)
table([['Objective','Implemented outcome'],['Find available rooms','Point-in-time search and whole-interval search; next scheduled start shown.'],['Keep schedules current','CRUD for rooms, dated bookings and recurring timetable entries.'],['Demonstrate core Java OOP','Validated models, abstract superclass, subclasses, overrides, overloads, interface, packages and custom exceptions.'],['Integrate Java with DBMS','Plain JDBC, parameter binding, object mapping, generated keys, constraints and transactions.'],['Provide reproducible evidence','18 automated tests, source paths, diagrams and real application captures.']],[1,2.6],'Table 1.1. Project objectives and implemented outcomes.')
new('1.3 Existing approach, proposed solution and scope','Chapter 1')
p('The supplied timetable exports provide class details but do not themselves provide an integrated room-search and reservation workflow. Manually consulting these exports can overlook a dated booking or an overlapping interval. The proposed solution adds a structured relational store and a Java application that presents both recurring and dated events through a common model.')
table([['Aspect','Manual / separate timetable lookup','RoomWise'],['Availability','User compares multiple entries.','Service combines timetable events and dated bookings.'],['Record maintenance','Direct file or SQL edits.','Validated CRUD forms and console commands.'],['Conflict handling','Depends on manual checking.','Atomic room and teacher overlap checks on writes.'],['Evidence','Static timetable content.','Persistent database state and reproducible tests.']],[1,1.7,1.7],'Table 1.2. Existing approach and proposed system.')
heading('1.4 Users and boundaries',1)
p('Campus users browse free rooms and occupied events. A trusted local operator maintains rooms and schedules. These are usage responsibilities, not authenticated roles: the current application has no login screen or authorization system. Anyone able to launch it with valid database credentials can reach its management functions.')
p('The scope is a same-day scheduling prototype with a weekly recurring timetable. It does not manage semesters, public holidays, room equipment, capacities, attendance, payment, notifications or university-wide identity. Dated bookings can be entered for any date; restricting past dates is not an implemented policy.')
heading('1.5 Organization of this report',1)
p('The following chapters cover requirements and feasibility; analysis and design; database design; implementation; verification; security and maintenance; and conclusions. Appendix A contains the exact schema. Appendix B provides application output evidence. Source-code images appear beside the relevant implementation explanation.')

new('CHAPTER 2: REQUIREMENTS AND FEASIBILITY')
heading('2.1 Functional requirements',1)
table([['ID','Requirement','Implementation / verification'],['FR-01','Connect to a configured local MySQL database.','DatabaseConnection; startup smoke check.'],['FR-02','Read available rooms at a date and time.','CampusService.search(date, time).'],['FR-03','Find rooms free for an entire interval.','search(date, from, until); boundary tests.'],['FR-04','Show occupied timetable and booking events.','occupied(...); runtime subclass dispatch.'],['FR-05','Create, read, update and delete rooms.','Rooms tab and console room submenu.'],['FR-06','Create, read, update and delete bookings.','Bookings tab; generated keys and transactions.'],['FR-07','Create, read, update and delete timetable rows.','Timetable tab; recurring conflict checks.'],['FR-08','Reject room or teacher overlaps.','JDBC conflict queries while holding guard row.'],['FR-09','Preserve existing data at startup.','Idempotent schema setup and explicit empty-only seed.'],['FR-10','Report invalid input without silently saving it.','Validated models, custom exceptions and UI messages.']],[.55,1.9,2.05],'Table 2.1. Functional requirements traceability.',9)
heading('2.2 Non-functional requirements',1)
p('Correctness takes priority over visual decoration. Inputs must satisfy schema limits; SQL values must be parameterized; writes must commit or roll back as a unit; and existing records must survive application restart. The user interface must identify errors and offer a repeatable workflow. Code must remain understandable enough for all three team members to explain.')
new('2.3 Technical requirements and feasibility','Chapter 2')
table([['Component','Project requirement / verified configuration'],['Language and runtime','Java 17 compatibility; local compilation and execution with JDK 21.'],['Build','Maven; JUnit Jupiter 5.11.4; Surefire 3.5.2.'],['Database','MySQL 8.0.16 or newer for enforced CHECK constraints; InnoDB tables.'],['JDBC driver','MySQL Connector/J 8.3.0, declared in pom.xml.'],['User interface','Java Swing desktop window and command-line console.'],['Host','Windows used for verification. Java code is portable; launcher is a Windows .bat file.'],['Suggested demonstration machine','Modern dual-core CPU, 4 GB RAM and sufficient space for JDK, Maven and MySQL. This is a practical recommendation, not a measured minimum.']],[1,3],'Table 2.2. Software and demonstration environment.')
heading('2.4 Feasibility study',1)
p('<b>Technical feasibility:</b> Java provides desktop widgets, date/time classes, collections and JDBC. MySQL provides relational constraints and transactions. The implemented dataset is small enough for a classroom demonstration, although the current service scans in-memory event lists instead of issuing optimized availability queries.')
p('<b>Operational feasibility:</b> the four tabs correspond to common tasks: search, rooms, bookings and timetable. An operator needs to understand date/time formats and use the Rooms tab to identify a valid room ID. No internet connection is required after dependencies and the local database are installed.')
p('<b>Economic and schedule feasibility:</b> the project uses a local Java/MySQL toolchain and needs no paid hosting. The main effort is implementation, data validation and testing. Completion evidence in this report is dated 9 November 2026; the stated assignment deadline remains 5 November 2026.')
heading('2.5 Acceptance criteria',1)
p('The prototype is accepted for this implementation snapshot when all three domain entities support CRUD, invalid intervals and foreign keys are rejected, both OOP dispatch mechanisms are visible in source, JDBC data persists between connections, concurrent conflicting writes produce one winner, and the test suite and demonstration can be repeated.')

new('CHAPTER 3: SYSTEM ANALYSIS AND DESIGN')
heading('3.1 Layered architecture',1)
p('Main is the composition root. It initializes the schema, creates JdbcCampusDao, injects it into CampusService and launches the selected UI. The UI imports the service and model packages; the service depends on CampusDao. SQL is kept in the DAO package and connection setup in the utility package.')
story.append(Diagram('architecture',355));cap('Figure 3.1. Implemented UI-service-DAO-database architecture.')
p('Constructor injection makes the dependency direction explicit. The persistence interface hides JDBC mechanics from the service, while returned Room, Booking and TimetableSlot objects carry validated domain state. DatabaseException preserves a cause internally while the UI displays a concise message.')
new('3.2 Use cases and interaction design','Chapter 3')
story.append(Diagram('usecase',325));cap('Figure 3.2. Use-case view of browsing and schedule maintenance.')
table([['Use case','Precondition','Main result'],['Search availability','Date/time parse successfully.','List of free rooms or active events.'],['Create reservation','Room exists; model is valid; no overlapping room/teacher event.','Generated ID returned after commit.'],['Edit reservation','Selected booking exists.','New values persist; its old row is excluded from conflict checks.'],['Delete room','No timetable or booking depends on the room.','One row deleted; otherwise an explanation is shown.']],[1.1,1.8,1.7],'Table 3.1. Principal use cases and results.')
new('3.3 Domain class design','Chapter 3')
story.append(Diagram('classes',365));cap('Figure 3.3. Actual domain inheritance and polymorphism.')
p('ScheduledEvent centralizes identity, room reference, teacher and validated start/end times. Booking adds an exact date. TimetableSlot adds a recurring weekday and course information. Their different occursOn implementations let the service select the events for a date without duplicating a complete search algorithm for each subclass.')
p('Room encapsulates its primary key and name; the setter validates nonblank text and the database column limit. FreeRoom is an immutable result record, not a persisted table. The hierarchy models the two scheduling concepts already present in the actual schema, rather than adding unused subclasses only for the report.')
heading('3.4 Design decisions',1)
p('The domain objects do not execute SQL. CampusDao supplies a stable persistence contract. JdbcCampusDao maps rows to those objects and implements the transaction boundary. The UI is responsible for input forms and display. This separation makes the link between an OOP concept and a database action easy to demonstrate.')
new('3.5 Booking flow and concurrency design','Chapter 3')
story.append(Diagram('flow',380));cap('Figure 3.4. Atomic schedule mutation and error path.')
p('Every DAO write takes the same guard-row lock. This conservative design serializes room, booking and timetable mutations, including teacher conflicts across different rooms. After the first transaction commits, a waiting transaction checks the committed state at READ COMMITTED isolation and rejects an overlap. The lock is released by commit or rollback.')
p('The design trades write throughput for clarity and correctness in a small campus prototype. A future implementation could use more selective locks. Direct SQL issued by another tool does not automatically acquire the guard; such external writes must follow the same protocol or be restricted.')
heading('3.6 Time interval model',1)
code('overlap = existingStart < requestedEnd\n       && existingEnd   > requestedStart')
p('Intervals are half-open: the start is included and the end excluded. A 09:00-10:00 event may be followed by a 10:00-11:00 event. Equal start and end values, reversed intervals and intervals crossing midnight are rejected. Recurring timetable entries are matched by weekday; bookings are matched by exact date.')

new('CHAPTER 4: DATABASE DESIGN')
heading('4.1 Database overview and relationships',1)
p('The implemented database has three domain tables and one internal synchronization table. Room names are stored once in rooms and referenced by both schedule tables. A room can have zero or many timetable rows and zero or many dated bookings. Every schedule row must reference one existing room.')
story.append(Diagram('er',420));cap('Figure 4.1. Entity-relationship diagram of the implemented four-table schema.')
p('schedule_guard is deliberately independent of the domain relationships. Its single row is a transaction mutex, not a user, booking or course entity. The application creates it idempotently and locks it during writes.','small')
new('4.2 Room and booking data dictionary','Chapter 4')
table([['Table / column','Type','Constraint / meaning'],['rooms.id','INT','Primary key; auto-increment.'],['rooms.room','VARCHAR(40)','Unique, NOT NULL room label.'],['bookings.id','INT','Primary key; auto-increment.'],['bookings.teacher','VARCHAR(150)','NOT NULL; teacher display name.'],['bookings.room_id','INT','NOT NULL foreign key to rooms.id.'],['bookings.booking_date','DATE','Exact date of the reservation.'],['bookings.start_time','TIME','Inclusive start; NOT NULL.'],['bookings.end_time','TIME','Exclusive end; must be greater than start_time.']],[1.25,1,2.15],'Table 4.1. Room and booking columns.')
heading('4.3 Booking constraints and indexes',1)
p('The primary key identifies a booking independently of its editable time and teacher fields. The foreign key prevents an orphan room reference. ON DELETE RESTRICT prevents direct SQL from deleting a room that still has bookings. chk_booking_times rejects zero-length and reversed intervals.')
p('idx_bookings_date_room_time begins with booking_date, followed by room_id, start_time and end_time. It supports date/room lookup patterns; the OR branch that also checks normalized teacher text can require additional scanning. No unmeasured claim is made that every conflict query uses only this index.')
p('There is no unique constraint on a whole booking interval because exact equality is not the same as overlap: 09:00-10:00 and 09:30-10:30 have different values but conflict. Overlap prevention is implemented by parameterized checks inside the guarded transaction.')
new('4.4 Timetable and synchronization data dictionary','Chapter 4')
table([['Column','Type','Meaning / rule'],['timetable_slots.id','INT','Auto-increment primary key.'],['room_id','INT','Foreign key to rooms.id; NOT NULL.'],['day_of_week','ENUM','MONDAY through SUNDAY.'],['start_time / end_time','TIME','Same-day interval; end greater than start.'],['course_code','VARCHAR(40)','Source course identifier; not declared unique.'],['course_name','VARCHAR(180)','Source course title.'],['section','VARCHAR(180)','Department/semester/group description.'],['teacher','VARCHAR(150)','Source teacher name.'],['class_type','ENUM','THEORY or LAB.'],['schedule_guard.id','TINYINT','Primary key with CHECK id=1; one initialized mutex row.']],[1.4,1,2],'Table 4.2. Timetable and guard columns.')
p('The timetable foreign key uses ON DELETE RESTRICT. Startup detects the legacy fk_slot_room cascade relationship and replaces it with fk_slot_room_restrict without deleting timetable rows. The migration has a dedicated integration test. idx_slots_day_room_time indexes weekday, room and time bounds.')
heading('4.5 Integrity rules',1)
p('The database enforces identity, required values, supported enum domains, room-name uniqueness, valid room references and positive time ranges. The Java model also validates names, lengths and time values before JDBC is called. Room and teacher overlap checks are application business rules evaluated within a database transaction; they are not SQL CHECK constraints or triggers.')
new('4.6 Functional dependencies and normalization','Chapter 4')
p('Within rooms, id determines room and the unique room name also identifies its row. In bookings, id determines teacher, room_id, booking_date, start_time and end_time. In timetable_slots, id determines the remaining class attributes. These are the keys actually declared in the schema.')
p('The tables store one value per column and have single-column surrogate primary keys, so there are no partial dependencies on a composite primary key. However, the timetable retains repeated course names, section descriptions and teacher names from the source exports. The report therefore does not claim a fully normalized course, faculty and offering model or BCNF certification.')
p('A course code is not assumed to uniquely determine a course title across all supplied source records. Earlier source inspection identified code/name collisions. Introducing a course table requires a verified identity rule, and teacher normalization requires stable staff identifiers. The current schema preserves the source information instead of silently merging records.')
table([['Design','Benefit','Trade-off'],['Separate rooms table','Avoids repeating the room label in every schedule row.','Requires a join or Java mapping for display.'],['Dated bookings separate from weekly classes','Keeps recurrence and exact-date semantics explicit.','Availability must combine both collections.'],['Course/teacher text retained','Preserves original export details.','Repeated text and name-based teacher identity remain.'],['Singleton guard','Simple atomic validation across all writers.','Serializes writes and must be honored by external tools.']],[1.15,1.65,1.65],'Table 4.3. Database design trade-offs.')
heading('4.7 Dataset provenance',1)
p('database/data/theory.json and labs.json are the retained source exports. database/real_data.sql contains 157 room rows and 4,167 timetable rows. The original conversion uses 24-hour afternoon times. The new --seed operation loads this dataset only when all domain tables are empty; it never overwrites an existing timetable. Imported source overlaps are retained for fidelity and are not represented as newly accepted reservations.')
new('4.8 CRUD, SQL and transaction semantics','Chapter 4')
table([['Entity','Create','Read','Update','Delete'],['Room','INSERT rooms(room)','SELECT id,room','UPDATE room WHERE id','DELETE unused row'],['Booking','INSERT; return key','SELECT bookings','UPDATE fields WHERE id','DELETE booking row'],['Timetable','INSERT; return key','SELECT timetable_slots','UPDATE fields WHERE id','DELETE timetable row']],[1,1.1,1.15,1.25,1.1],'Table 4.4. Implemented CRUD coverage.',8.8)
p('INSERT returns the generated key through Statement.RETURN_GENERATED_KEYS and ResultSet. UPDATE and DELETE verify that exactly one row was affected; a missing selection produces NotFoundException. Editing a booking or timetable entry excludes its own primary key from conflict queries, so an unchanged row does not conflict with itself.')
code('SELECT id FROM schedule_guard WHERE id = 1 FOR UPDATE;\n-- overlap query uses bound parameters\nWHERE day_of_week = ?\n  AND (room_id = ? OR LOWER(TRIM(teacher)) = LOWER(TRIM(?)))\n  AND start_time < ? AND end_time > ? AND id <> ?')
p('For a new booking, the DAO checks weekly classes on its weekday and dated bookings on its exact date. For a recurring class, it checks other classes on the weekday and bookings whose date has the same weekday. Teacher matching trims surrounding spaces and compares without case; it is not a substitute for a unique staff ID.')
heading('4.9 ACID in this implementation',1)
p('<b>Atomicity:</b> a write commits as one unit or rolls back on SQL/runtime failure. <b>Consistency:</b> model checks, business conflict checks and relational constraints reject invalid states. <b>Isolation:</b> READ COMMITTED plus the shared guard row serializes application writers. <b>Durability:</b> committed rows are managed by InnoDB; operational durability still depends on MySQL configuration, storage and backups.')

new('CHAPTER 5: IMPLEMENTATION')
heading('5.1 Project structure and responsibility mapping',1)
table([['Package / file','Responsibility'],['roomwise.Main','Initializes database; wires DAO to service; selects Swing, console or --seed.'],['model','Room, ScheduledEvent, Booking, TimetableSlot and FreeRoom.'],['dao','CampusDao contract; JdbcCampusDao CRUD and transactions; DatabaseInitializer schema/seed.'],['service.CampusService','Availability, overloads, occupied-event selection and CRUD facade.'],['ui','RoomFinderWindow and ConsoleMenu; no DAO imports.'],['util','DatabaseConnection and Validation.'],['exception','DatabaseException, BookingConflictException and NotFoundException.'],['src/test/java/roomwise','ModelTest and DatabaseIntegrationTest.']],[1.3,3.1],'Table 5.1. Source package map.')
heading('5.2 OOP concept-to-code map',1)
table([['Concept','Actual implementation'],['Encapsulation','Room private fields and validated setName; event private final fields.'],['Abstraction','abstract ScheduledEvent; CampusDao interface.'],['Inheritance','Booking and TimetableSlot extend ScheduledEvent.'],['Runtime polymorphism','occursOn and description overrides invoked through ScheduledEvent.'],['Compile-time polymorphism','Three search overloads; two occupied overloads.'],['Packages','model / dao / service / ui / util / exception.'],['Exception handling','Custom runtime types, rollback, try-with-resources and UI error messages.']],[1.2,3.2],'Table 5.2. OOP concepts and implementation evidence.')
new('5.3 Encapsulation and validation','Chapter 5')
excerpt('model/Room.java',1,22,'code-room','Figure 5.1. Encapsulated Room state and validated setter.')
p('Room.id is private and final, so a caller cannot rewrite its persistent identity. Room.name is private and can change only through setName. Validation.text trims the value, rejects blank input and enforces the VARCHAR(40) limit. A failed setter leaves the previous valid name unchanged; ModelTest verifies this behavior.')
p('The event superclass uses private final fields because an event update is represented by a newly constructed object with the same ID. This ensures that every proposed time interval is validated before the DAO receives it. Encapsulation here protects business invariants, not merely field visibility.')
new('5.4 Abstraction and shared scheduling behavior','Chapter 5')
excerpt('model/ScheduledEvent.java',1,34,'code-event','Figure 5.2. Abstract event model, common state and overlap rule.')
p('An abstract class cannot be instantiated directly. ScheduledEvent defines what all scheduled items have in common and leaves two variable behaviors to its subclasses. Its constructor validates identity, teacher text and interval length. The final accessors and overlaps method provide one common interpretation of interval boundaries.')
new('5.5 Inheritance and method overriding','Chapter 5')
excerpt('model/Booking.java',1,17,'code-booking','Figure 5.3. Booking inherits the common event contract.')
excerpt('model/TimetableSlot.java',21,30,'code-slot','Figure 5.4. TimetableSlot overrides recurrence and description behavior.')
p('Booking matches one LocalDate; TimetableSlot matches the date\'s DayOfWeek. Both objects are valid ScheduledEvent instances. This is a meaningful is-a relationship: both can occupy a room, overlap a time interval and provide a display description, but they differ in recurrence. The report does not claim that unrelated GUI inheritance supplies the only domain OOP evidence.')
new('5.6 Runtime and compile-time polymorphism','Chapter 5')
excerpt('service/CampusService.java',27,51,'code-polymorphism','Figure 5.5. Common event collection and overloaded search methods.')
p('events(date) combines timetable and booking objects into List&lt;ScheduledEvent&gt;. Calling event.occursOn(date) dispatches to the appropriate override at runtime. The occupied display similarly calls description through the superclass reference. Adding a compatible event type would not require duplicating the whole presentation loop.')
p('search(date), search(date, at) and search(date, from, until) use the same method name with different parameter lists. Java chooses the overload at compile time. The interval overload tests the entire requested period; the point overload reports the next occupied start after the selected time. These are separate use cases, not interchangeable results.')
new('5.7 Interfaces and package integration','Chapter 5')
excerpt('dao/CampusDao.java',1,23,'code-interface','Figure 5.6. CampusDao persistence interface for all domain CRUD operations.')
p('CampusService receives a CampusDao through its constructor. Main supplies a JdbcCampusDao instance. This is interface-based abstraction: the service knows the available operations without owning a JDBC connection or SQL string. The current implementation uses one JDBC implementation; the interface provides a boundary for testing and future persistence changes.')
p('A complete booking path is: form input -&gt; new Booking -&gt; CampusService.createBooking -&gt; CampusDao.createBooking -&gt; JdbcCampusDao transaction -&gt; MySQL INSERT -&gt; generated ID -&gt; refreshed UI. The Booking object links inheritance and validation to a concrete database operation.')
new('5.8 JDBC connectivity and resource management','Chapter 5')
excerpt('util/DatabaseConnection.java',1,29,'code-connection','Figure 5.7. External configuration and JDBC connection creation.')
p('DatabaseConnection opens db.properties from the working directory, or from the path supplied by the roomwise.config system property. The build no longer embeds that credential file in the JAR. The roomwise.db.url override is used for isolated tests and demonstrations. The report and code images do not contain the local username, password or complete private connection settings.')
p('The factory uses DriverManager and the declared Connector/J driver. Connections have finite connect and socket timeouts. Try-with-resources closes the configuration stream, connections, statements and result sets. IO and SQL errors are wrapped in DatabaseException with a user-facing message. Prepared parameters keep user values separate from SQL syntax. [2]')
new('5.9 Transaction implementation and exception handling','Chapter 5')
excerpt('dao/JdbcCampusDao.java',15,37,'code-transaction','Figure 5.8. Guarded write transaction with commit and rollback.')
p('The shared write helper sets the isolation level, disables auto-commit and locks schedule_guard. The callback then performs the entity-specific work. A successful callback commits. A SQLException or RuntimeException triggers rollback; a rollback failure is attached as a suppressed exception so the original failure is not lost. [3]')
p('BookingConflictException expresses a business collision; NotFoundException identifies a stale/missing record. DatabaseException wraps JDBC failures. Swing catches runtime errors and displays a dialog. The console catches recoverable operation errors and returns to its menu. This is explicit error reporting rather than swallowing an exception.')
new('5.10 CRUD implementation and generated keys','Chapter 5')
excerpt('dao/JdbcCampusDao.java',119,145,'code-crud','Figure 5.9. Booking and timetable INSERT, UPDATE and DELETE methods.')
p('The booking and timetable writes bind values taken from validated model objects. Create returns a database-generated ID. Update keeps the primary key and replaces editable values only after conflict checks. Delete removes the selected row inside the same guarded transaction. Room deletion checks dependents and is also protected by foreign keys.')
new('5.11 Object mapping, UI integration and setup','Chapter 5')
excerpt('dao/JdbcCampusDao.java',46,64,'code-mapping','Figure 5.10. Mapping JDBC ResultSet rows into domain objects.')
p('Read operations reconstruct Room, Booking and TimetableSlot objects using typed LocalDate/LocalTime values. Those constructors apply the same domain invariants used by new UI input. The service can therefore work with objects, while persistence details remain in the DAO.')
heading('5.12 Build and run procedure',1)
code('cd RoomWise\nmvn package dependency:copy-dependencies -DincludeScope=runtime\njava -cp "target/classes;target/dependency/*" roomwise.Main\njava -cp "target/classes;target/dependency/*" roomwise.Main --console')
p('Create the MySQL database and configure a local db.properties before running. For a new empty schema only, run Main --seed after startup creates the tables. Existing data is preserved and nonempty seeds are refused. The Windows run_roomwise.bat launcher offers Swing or console and cleans generated output after the application exits. On Unix-like systems the classpath separator is a colon.','small')

new('CHAPTER 6: VERIFICATION AND TEST PLAN')
heading('6.1 Verification method and environment',1)
p('Verification was performed on 9 November 2026 with JDK 21, Maven and local MySQL. Model tests run without a database. Integration tests create a uniquely named temporary database, apply the real schema, exercise JDBC operations and remove that test database afterward. They never clear the configured campus database.')
code('mvn test\nmvn test "-Droomwise.integration=true"')
p('The first command runs four model tests and skips the explicitly gated integration class. The second runs all eighteen tests and requires database privileges to create and remove the temporary test schema. A skipped integration class must not be reported as a full database test pass.')
table([['Suite','Tests','Failures','Errors','Skipped in full run'],['ModelTest','4','0','0','0'],['DatabaseIntegrationTest','14','0','0','0'],['Total','18','0','0','0']],[1.8,.55,.6,.6,1.1],'Table 6.1. Observed automated test result.')
heading('6.2 Build and startup checks',1)
p('Maven test and package completed successfully. A console startup against the configured campus database reached "Database ready. Existing records preserved.", displayed the new menu and exited normally. The built JAR was inspected and contains no db.properties credential file. The verified local MySQL version was 8.0.40; the campus database retained 157 rooms and 4,167 timetable records after the upgrade.')
p('Application screenshots were taken from the actual Swing window using a separate report demonstration database. The dataset plus clearly labeled demo records enabled browsing and editing evidence without adding demo reservations to the campus data.')
new('6.3 Automated test cases','Chapter 6')
table([['ID','Test condition','Observed result'],['UT-01','Invalid/blank room rename and valid rename.','Rejected invalid name; prior value preserved.'],['UT-02','Half-open overlap and adjacent intervals.','Adjacent slots allowed; actual overlap detected.'],['UT-03','Equal times, blank teacher, long room name.','Model construction rejected.'],['UT-04','Superclass references to both subclasses.','Exact-date and weekly dispatch differed correctly.'],['IT-01','Room CRUD, duplicate name, stale ID.','CRUD passed; duplicate and missing ID rejected.'],['IT-02','Booking create/read/update/delete.','Generated ID and updated time persisted.'],['IT-03','Timetable create/read/update/delete.','All four operations passed.'],['IT-04','Room conflict and same teacher in another room.','Both rejected; adjacent booking accepted.'],['IT-05','Move a booking into an occupied interval.','Conflict raised; original booking retained.'],['IT-06','Recurring class overlaps a dated reservation.','New class rejected.'],['IT-07','Search at boundaries and over full interval.','Both subclasses included; boundaries correct.']],[.65,2.15,1.75],'Table 6.2. Model and functional integration tests.',9)
new('6.4 Integrity, concurrency and migration tests','Chapter 6')
table([['ID','Test condition','Observed result'],['IT-08','Delete referenced room; invalid FK and time via SQL.','Database rejected all invalid changes.'],['IT-09','Quoted SQL-like room label as bound value.','Stored as text; room table remained intact.'],['IT-10','Restart initializer with edited data.','Room and timetable rows preserved.'],['IT-11','Two simultaneous bookings for the same room.','Exactly one successful commit.'],['IT-12','Two rooms, same teacher, simultaneous times.','Exactly one successful commit.'],['IT-13','Explicit initial seed, then repeat on nonempty data.','157 rooms / 4,167 slots loaded; second seed refused.'],['IT-14','Legacy CASCADE foreign key migration.','Rows retained; direct room delete then rejected.']],[.65,2.15,1.75],'Table 6.3. Integrity, concurrency and migration tests.',9)
heading('6.5 Manual verification and evidence limits',1)
table([['Check','Evidence / status'],['Swing search','Free and occupied views observed for 9 November 2026 at 09:00.'],['Management tabs','Rooms, bookings and timetable tabs opened; stored values visible.'],['Booking edit form','Selected demo booking opened with persisted 18:00-19:30 values.'],['Console','Startup and clean exit observed against configured campus database.'],['End-to-end CRUD','Executed through CampusService/JdbcCampusDao in tests and demo helper; not every Swing form submission was manually clicked.'],['Not measured','High-volume load, network outage recovery, multi-machine deployment and long-running stress.']],[1.05,3.3],'Table 6.4. Manual verification coverage and limits.')
p('The test suite establishes repeatable behavior for the stated cases. It is not proof that every possible input or environment is correct. Remaining limitations are described in Chapter 7 rather than represented as completed features.')
new('6.6 Demonstration and team preparation','Chapter 6')
table([['Step','Action','Explain during evaluation'],['1','Start MySQL and launch RoomWise.','External configuration, JDBC driver and package layers.'],['2','Search 2026-11-09 at 09:00; compare Occupied.','Weekly classes, dated bookings, half-open intervals.'],['3','Add a uniquely named DEMO room.','Validation, INSERT and generated primary key.'],['4','Add a booking, then refresh and edit its end time.','Create/read/update and object-to-row mapping.'],['5','Attempt a conflicting booking.','Guard-row lock, overlap query, rollback and error.'],['6','Delete demo booking, then delete the empty demo room.','Delete, referential integrity and safe cleanup.'],['7','Show ScheduledEvent and both subclasses.','Abstract behavior, inheritance and dynamic dispatch.'],['8','Run the test command and inspect its summary.','What was tested and what remains unverified.']],[.45,1.85,2],'Table 6.5. Suggested demonstration sequence.')
heading('6.7 Team readiness',1)
p('Suggested presentation leads: Adithya Narayana Anand explains architecture, Java models and polymorphism; Aadithya T explains schema, JDBC and CRUD; Mitran Reddy explains verification, concurrency and the live demonstration. These are suggested presentation assignments, not claims about historical contribution. Each team member should rehearse the complete sequence and answer questions from all sections.')
p('Before evaluation, every member should be able to explain why SQL values are bound, why equal booking boundaries are allowed, why a primary key does not prevent interval overlap, what rollback does, how the abstract method dispatch works, and why the current application is a trusted local prototype without authentication.')

new('CHAPTER 7: SECURITY, LIMITATIONS, AND MAINTENANCE')
heading('7.1 Implemented security and integrity controls',1)
p('All user data passed into SQL is bound using PreparedStatement. Dynamic SQL fragments select only fixed internal table/condition choices; user strings do not become SQL syntax. Validated constructors limit text lengths and reject invalid time ranges. Database keys, uniqueness, enum domains and CHECK constraints provide a second integrity layer. [2, 4]')
p('Credentials are read from a local file outside the built JAR. The final report contains no database password. Users should keep this file private and grant the application only the necessary database privileges. Existing repository history may already include the local credential file from earlier work; ignoring a file does not remove historical copies. Changing repository history and rotating credentials require a separate coordinated maintenance action.')
p('SQL errors are wrapped before being shown in the UI. The original cause remains available to debugging code. There is no centralized audit log, authentication, authorization, encrypted credential store or enforced remote TLS policy. These controls are not claimed as implemented.')
heading('7.2 Known limitations',1)
table([['Limitation','Practical implication'],['No login or role restrictions','Use only as a trusted local academic prototype.'],['Teacher identity is text','Aliases, homonyms and inconsistent spelling can produce incorrect identity matches.'],['Recurring schedule has no semester dates','A weekly entry applies to every matching weekday.'],['Same-day intervals only','Overnight events must be redesigned or split.'],['Source-data overlaps retained','Imported timetable rows can already overlap; they are not silently repaired.'],['Global guard serializes writes','Clear correctness mechanism, limited write concurrency.']],[1.4,2.9],'Table 7.1. Security and scheduling limitations.')
new('7.3 Performance and maintenance plan','Chapter 7')
p('Availability currently loads event lists through the DAO and filters them in Java. This makes the OOP behavior visible but can become slow as data grows. The UI also performs synchronous service calls, so a slow database may delay the window. Future optimization should use focused date/weekday queries, background Swing workers and measured query plans while preserving the same service contract.')
p('Room deletion is deliberately restricted when dependent schedules exist. An operator must review and remove or reassign those records first. The application does not automatically archive deleted bookings, and there is no undo feature. Before substantial data maintenance, take a database backup and verify that restoration works.')
table([['Maintenance activity','Procedure / frequency'],['Before a demonstration','Check MySQL service, local configuration, Java version and report-matching build.'],['After a code change','Run model tests and relevant integration tests; update concept map and report if behavior changed.'],['Before a schema change','Back up data, define migration, test it on a separate database, preserve foreign keys.'],['After timetable updates','Review duplicate/overlapping source rows and verify representative room/date queries.'],['For credential changes','Update private config; keep built artifacts and repository history under review.'],['For data recovery','Restore backup to a separate database first; verify counts and sample relationships before replacing live data.']],[1.15,3.2],'Table 7.2. Maintenance responsibilities.')
heading('7.4 Troubleshooting',1)
p('If connection fails, verify that MySQL is running and db.properties is in the working directory or selected with roomwise.config. If a write is rejected, check the room ID, duplicate room name, text length, date/time format and overlapping room/teacher events. If --seed refuses to run, it is protecting existing data; do not delete records simply to bypass that check. If a generated JAR is locked, close the process using it before running Maven clean.')

new('CHAPTER 8: CONCLUSION AND FUTURE WORK')
heading('8.1 Conclusion',1)
p('RoomWise now provides a working integration of Java OOP and relational database operations. Its Java model distinguishes a dated booking from a recurring timetable entry through inheritance and overridden behavior. The service uses those objects to compute room availability, while the persistence interface and JDBC implementation keep database details separate from the UI.')
p('Rooms, bookings and timetable entries each support Create, Read, Update and Delete. The implementation uses generated primary keys, room foreign keys, input validation, prepared parameters and explicit transactions. A database guard row prevents two cooperating application writers from both accepting a conflicting room or teacher schedule. Eighteen automated tests passed for the documented snapshot.')
p('The report connects concepts to actual classes and operations instead of describing only theoretical features. It includes the current SQL schema, source-code images, real Swing captures, verification boundaries and a demonstration script. The prototype remains suitable for a controlled academic demonstration; deployment to a wider campus audience requires identity, authorization and operational improvements.')
heading('8.2 Prioritized future work',1)
table([['Priority','Enhancement','Reason'],['1','Authenticated accounts and authorized management roles','Protect schedule modification from untrusted users.'],['2','Stable faculty/course identities and normalized offerings','Resolve name matching and repeated source text.'],['3','Semester periods, holidays and exception dates','Represent a real academic calendar.'],['4','Targeted DAO queries, background UI tasks and paging','Improve responsiveness as the dataset grows.'],['5','Audit history, soft cancellation and restoration workflow','Support traceability and recovery.'],['6','Capacity/equipment filters and utilization reporting','Extend room discovery after core data quality is established.']],[.55,2.15,1.8],'Table 8.1. Future development priorities.')

new('REFERENCES')
refs=[
('[1] Oracle. Object-Oriented Programming Concepts. The Java Tutorials.','https://docs.oracle.com/javase/tutorial/java/concepts/'),
('[2] Oracle. Using Prepared Statements. JDBC Basics.','https://docs.oracle.com/javase/tutorial/jdbc/basics/prepared.html'),
('[3] Oracle. Using Transactions. JDBC Basics.','https://docs.oracle.com/javase/tutorial/jdbc/basics/transactions.html'),
('[4] Oracle / MySQL. FOREIGN KEY Constraints. MySQL 8.0 Reference Manual.','https://dev.mysql.com/doc/refman/8.0/en/create-table-foreign-keys.html')]
for title,url in refs:p(escape(title)+'<br/><link href="'+url+'" color="#253858">'+escape(url)+'</link><br/>Accessed 9 November 2026.','small')
p('[5] RoomWise project source. src/main/java/roomwise/, pom.xml and database/schema.sql. Local implementation snapshot verified 9 November 2026. Primary evidence for all implementation claims.','small')
p('[6] Supplied campus timetable exports: database/data/theory.json and database/data/labs.json; generated SQL: database/real_data.sql. Data supplied with the project; no independent publication date was provided.','small')
p('[7] ModelTest and DatabaseIntegrationTest. Local Maven Surefire results, 9 November 2026: 18 tests, zero failures and zero errors in the explicitly enabled complete run.','small')
p('[8] NAMMA_CHENNAI.pdf, supplied by the user. Used only as a visual and structural reference for the cover, REC logo, preliminary pages and certificate alignment. Its project content, authorship, code and test results are not part of RoomWise.','small')
p('The Java tutorial pages above describe foundational concepts and note their JDK 8 origin. The actual RoomWise project targets Java 17 and was verified with JDK 21. Source-specific implementation claims in this report are supported by the local code and test results, not inferred from the tutorial examples.','small')

new('APPENDIX A: SQL SCHEMA')
p('The following listing is the exact current database/schema.sql. It creates missing tables and the synchronization row without dropping existing application data. Main respects the configured database; manual execution of the file selects roomwise_db. The Java initializer performs the documented legacy foreign-key migration separately.','small')
schema=(ROOT/'database/schema.sql').read_text().splitlines()
code('\n'.join(schema[:31]))
new('Appendix A / SQL schema continued')
code('\n'.join(schema[31:]))
heading('A.1 Initial data and migration notes',1)
p('Use the --seed command only for first-time population of an empty schema. It checks all three domain tables under the guard lock and imports the supplied SQL inside a transaction. Normal startup does not compare the timetable to a fixed row count and does not reload the source data. This preserves legitimate CRUD changes.')
p('For an existing legacy schema, the initializer replaces the timetable-room CASCADE foreign key with a RESTRICT relationship. This prevents a room deletion from silently removing imported class rows. The migration is tested with retained room and timetable fixtures.')
heading('A.2 Useful read-only demonstration queries',1)
code('SELECT COUNT(*) AS rooms FROM rooms;\nSELECT COUNT(*) AS timetable_rows FROM timetable_slots;\nSELECT id, teacher, booking_date, start_time, end_time\nFROM bookings ORDER BY id;\nSELECT r.room, b.booking_date, b.start_time, b.end_time\nFROM rooms r JOIN bookings b ON b.room_id = r.id;')

new('APPENDIX B: OUTPUT SCREENSHOTS')
p('The following screenshots were captured from the running Swing application on 9 November 2026. The title bar identifies a separate report demonstration database. Screenshots are genuine application captures; the code images in Chapter 5 are separately labeled source renderings.')
p('The demo database contains the original 157 rooms and 4,167 timetable rows plus one DEMO-SEMINAR room, one demo weekly class and one demo booking. Therefore its management status shows 158 rooms, 4,168 timetable records and one booking. These additional rows are demonstration fixtures, not claims about the source dataset. The demo database was removed after capture.')
table([['Evidence','Observed value'],['Search date/time','2026-11-09 (Monday), 09:00'],['Free rooms in demo database','92 (91 from the source room set plus the demo room)'],['Occupied events / distinct rooms','77 active events across 66 distinct rooms'],['Persisted demo booking','ID 1; room 158; Demo Faculty; 18:00-19:30'],['Demonstrated rejected operation','An overlapping booking was rejected.'],['Demonstrated delete','Temporary booking ID 2 was deleted; one demo booking remained.']],[1.3,3],'Table B.1. Screenshot provenance and observed values.')
p('The timetable dataset can contain multiple active rows for the same room. Consequently occupied-event counts must not be described as distinct-room counts. The revised UI displays both figures. Wide screenshot pages follow to keep labels readable; table cells may shorten long course names, which can be inspected in the edit form.')
screens=[('B.1','Free-room search','app-free.png','The point search lists rooms with no active class or booking at 09:00 and shows their next occupied start. The demonstration room accounts for one additional free result.'),('B.2','Occupied-event search','app-occupied.png','The result contains 77 events in 66 rooms. Recurring class rows are shown here; the same view also includes dated Booking objects when their interval is active.'),('B.3','Room CRUD screen','app-rooms.png','The Rooms tab exposes Add, Edit selected, Delete selected and Refresh. Primary keys come from MySQL; a room with dependent schedules cannot be deleted.'),('B.4','Persisted booking after update','app-booking.png','The created reservation was updated from an end time of 19:00 to 19:30. Refresh reads the stored row through JDBC. The temporary second reservation was deleted.'),('B.5','Booking edit form','app-edit.png','The selected booking opens with its stored values. Room ID, teacher, date and interval are editable. Saving constructs a validated Booking and invokes conflict-checked update logic.'),('B.6','Timetable CRUD screen','app-timetable.png','Recurring class records include their room reference, weekday, interval, course, section, teacher and type. The Add/Edit/Delete actions use the same service and transactional DAO boundary.')]
story.append(NextPageTemplate('wide'))
for num,title,file,desc in screens:
    story.append(PageBreak());heading(title,toc=False);img(WORK/file,maxwidth=landscape(A4)[0]-36*mm,maxheight=landscape(A4)[1]-54*mm-78)
    cap('Figure '+num+'. '+title+'.');p(desc,'small')
story.append(NextPageTemplate('body'));new('Appendix B / Recorded demonstration output')
p('The transcript below is output from the isolated demonstration helper calling the actual CampusService and JDBC implementation. It is a textual run record, not a terminal screenshot. It complements the genuine window captures above.','small')
code((WORK/'demo-output.txt').read_text())
heading('B.7 Verification record',1)
for name in ['roomwise.ModelTest.txt','roomwise.DatabaseIntegrationTest.txt']:
    report=ROOT/'target/surefire-reports'/name
    if not report.exists(): report=WORK/name
    lines=report.read_text().splitlines()
    p(escape(next(x for x in lines if x.startswith('Tests run:'))),'small')
p('The local build used for this report contains 17 production Java source files. The exact schema and source images in this report refer to the files under RoomWise. All signatures and the practical-examination date remain blank for the institution and team to complete.','small')

OUT.parent.mkdir(parents=True,exist_ok=True)
Doc(OUT).multiBuild(story)
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SRC.rglob('*.java'))}
manifest['database/schema.sql']=hashlib.sha256((ROOT/'database/schema.sql').read_bytes()).hexdigest()
(WORK/'source-hashes.json').write_text(json.dumps(manifest,indent=2))
print(OUT)
