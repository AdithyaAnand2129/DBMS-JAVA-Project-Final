import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.time.*;
import java.util.*;
import javax.swing.*;
import roomwise.dao.*;
import roomwise.model.*;
import roomwise.service.*;
import roomwise.util.DatabaseConnection;
import roomwise.ui.RoomFinderWindow;

/** Isolated demonstration database; never changes the configured campus data. */
public class DemoSession {
    static final String DB="roomwise_demo_report_20261109";
    public static void main(String[] args) throws Exception {
        Properties p=new Properties();try(InputStream in=Files.newInputStream(Path.of("db.properties"))) {p.load(in);}
        if(args.length>0 && args[0].equals("cleanup")) {
            try(Connection c=DatabaseConnection.open();PreparedStatement s=c.prepareStatement("DROP DATABASE IF EXISTS "+DB)) {s.execute();}
            System.out.println("Isolated report demonstration database removed.");return;
        }
        try(Connection c=DatabaseConnection.open();PreparedStatement s=c.prepareStatement("CREATE DATABASE "+DB)) {s.execute();}
        System.setProperty("roomwise.db.url",p.getProperty("db.url").replaceFirst("(jdbc:mysql://[^/]+/)[^?]*","$1"+DB));
        DatabaseInitializer.initialize();DatabaseInitializer.seed();
        CampusService service=new CampusService(new JdbcCampusDao());
        int room=service.createRoom("DEMO-ROOM-01");
        System.out.println("CREATE room #"+room+" DEMO-ROOM-01");
        service.updateRoom(room,"DEMO-SEMINAR");System.out.println("UPDATE room #"+room+" DEMO-SEMINAR");
        LocalDate day=LocalDate.of(2026,11,9);
        int booking=service.createBooking(new Booking(0,room,"Demo Faculty",day,LocalTime.of(18,0),LocalTime.of(19,0)));
        System.out.println("CREATE booking #"+booking+" 2026-11-09 18:00-19:00");
        service.updateBooking(new Booking(booking,room,"Demo Faculty",day,LocalTime.of(18,0),LocalTime.of(19,30)));
        System.out.println("UPDATE booking #"+booking+" end=19:30; READ end="+service.bookings().get(0).end());
        try {service.createBooking(new Booking(0,room,"Another Teacher",day,LocalTime.of(18,30),LocalTime.of(19,0)));}
        catch(roomwise.exception.BookingConflictException e) {System.out.println("CONFLICT REJECTED: "+e.getMessage());}
        int slot=service.createSlot(new TimetableSlot(0,room,"Demo Faculty",DayOfWeek.MONDAY,LocalTime.of(17,0),LocalTime.of(18,0),"DEMO-OOP","OOP Demonstration","CSE Semester 3",TimetableSlot.Type.THEORY));
        System.out.println("CREATE timetable #"+slot+" MONDAY 17:00-18:00");
        int disposable=service.createBooking(new Booking(0,room,"Demo Faculty",day.plusDays(1),LocalTime.of(18,0),LocalTime.of(19,0)));
        service.deleteBooking(disposable); System.out.println("DELETE temporary booking #"+disposable+"; remaining="+service.bookings().size());
        System.out.println("SOURCE DATA: 157 rooms; 4167 timetable records. Demo adds 1 room, 1 timetable row and 1 booking.");
        System.out.println("MONDAY 09:00 free rooms="+service.search(day,LocalTime.of(9,0)).size()+" occupied events="+service.occupied(day,LocalTime.of(9,0)).size());
        SwingUtilities.invokeLater(() -> {RoomFinderWindow frame=new RoomFinderWindow(service);frame.setTitle("RoomWise | Report demonstration database");frame.setVisible(true);});
    }
}
