import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import roomwise.dao.*;
import roomwise.service.*;
import roomwise.util.DatabaseConnection;
import roomwise.ui.ConsoleMenu;

public class TerminalEvidence {
    static final Path OUT=Path.of("C:/Users/adith/AppData/Local/Temp/roomwise-terminal-report");
    static void session(CampusService service,String name,String commands) throws Exception {
        try(PrintStream output=new PrintStream(Files.newOutputStream(OUT.resolve(name+".txt")))) {
            new ConsoleMenu(service,new Scanner(commands),output).start();
        }
        Files.writeString(OUT.resolve(name+"-inputs.txt"),commands);
    }
    public static void main(String[] args) throws Exception {
        String database="roomwise_evidence_"+UUID.randomUUID().toString().replace("-", "");
        Properties props=new Properties();
        try(InputStream in=Files.newInputStream(Path.of("db.properties"))) {props.load(in);}
        try(Connection c=DatabaseConnection.open();PreparedStatement s=c.prepareStatement("CREATE DATABASE "+database)) {s.execute();}
        try {
            System.setProperty("roomwise.db.url",props.getProperty("db.url").replaceFirst("(jdbc:mysql://[^/]+/)[^?]*","$1"+database));
            DatabaseInitializer.initialize(); DatabaseInitializer.seed();
            CampusService service=new CampusService(new JdbcCampusDao());
            session(service,"menu","0\n");
            session(service,"free","1\n2026-11-09\n09:00\n0\n");
            session(service,"room-crud","3\nC\nDEMO-ROOM\n3\nU\n158\nDEMO-SEMINAR\n0\n");
            session(service,"booking-create","4\nC\n158\nDemo Faculty\n2026-11-09\n18:00\n19:00\n4\nR\n0\n");
            session(service,"booking-update","4\nU\n1\n158\nDemo Faculty\n2026-11-09\n18:00\n19:30\n4\nR\n0\n");
            session(service,"conflict","4\nC\n158\nOther Teacher\n2026-11-09\n18:30\n19:00\n0\n");
            session(service,"occupied","2\n2026-11-09\n18:15\n0\n");
            session(service,"timetable","5\nC\n158\nDemo Faculty\nMONDAY\n17:00\n18:00\nDEMO-OOP\nJava Demonstration\nCSE-S3\nTHEORY\n5\nU\n4168\n158\nDemo Faculty\nMONDAY\n17:00\n17:30\nDEMO-OOP\nJava Demonstration\nCSE-S3\nTHEORY\n2\n2026-11-09\n17:15\n0\n");
            session(service,"delete","4\nD\n1\nDELETE\n4\nR\n5\nD\n4168\nDELETE\n3\nD\n158\nDELETE\n0\n");
            if(service.rooms().size()!=157 || service.slots().size()!=4167 || !service.bookings().isEmpty()) throw new IllegalStateException("Demo cleanup counts do not match");
            Files.writeString(OUT.resolve("verification.txt"),"All recorded console sessions used actual ConsoleMenu, CampusService and JDBC.\nFinal isolated data: 157 rooms / 4167 timetable slots / 0 bookings.\n");
        } finally {
            System.clearProperty("roomwise.db.url");
            try(Connection c=DatabaseConnection.open();PreparedStatement s=c.prepareStatement("DROP DATABASE "+database)) {s.execute();}
        }
        System.out.println("Terminal evidence recorded; isolated database removed.");
    }
}
