from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap
w=Path(r'C:/Users/adith/AppData/Local/Temp/roomwise-terminal-report')
font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',24)
for name in ['menu','free','room-crud','booking-create','booking-update','conflict','occupied','timetable','delete']:
    lines=(w/(name+'.txt')).read_text().splitlines()
    if name!='menu':
        lines=[l for l in lines if l.strip() and not l.startswith(('==========','1. ','2. ','3. ','4. ','5. ','6. ','0. '))]
    if name=='free':
        lines=lines[:16]+['[... middle room rows omitted from this excerpt ...]']+lines[-2:]
    display=[]
    for line in lines:
        display.extend(textwrap.wrap(line,80,replace_whitespace=False,drop_whitespace=False) or [''])
    im=Image.new('RGB',(1220,100+34*len(display)),'#f7f7f7')
    d=ImageDraw.Draw(im);d.rectangle((0,0,1220,55),fill='#e3e6e9');d.text((25,14),'ROOMWISE | Captured terminal output | '+name,font=font,fill='#1a2738')
    for i,line in enumerate(display):d.text((25,78+i*34),line,font=font,fill='#101820')
    im.save(w/(name+'.png'))
print('Nine output images created from logs')
