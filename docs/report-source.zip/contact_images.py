from pypdf import PdfReader
from PIL import Image,ImageDraw
from pathlib import Path
reader=PdfReader(r'C:\Users\adith\Downloads\NAMMA_CHENNAI.pdf')
seen={}
for image in reader.pages[0].images:
    if image.name not in seen:
        seen[image.name]=image.image.convert('RGB').copy()
items=list(seen.items())
cell_w,cell_h=170,135
sheet=Image.new('RGB',(cell_w*5,cell_h*((len(items)+4)//5)),(245,245,245))
d=ImageDraw.Draw(sheet)
for i,(name,im) in enumerate(items):
    im.thumbnail((150,100))
    x=(i%5)*cell_w; y=(i//5)*cell_h
    sheet.paste(im,(x+(150-im.width)//2,y))
    d.text((x+4,y+105),f'{name} {seen[name].size}',fill=(0,0,0))
sheet.save('tmp/images_contact.png')
print('unique',len(items))
