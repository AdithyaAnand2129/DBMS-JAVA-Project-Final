package roomwise;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Field;
import java.time.DayOfWeek;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/** Renders real RoomWise Swing query results to appendix images. */
public final class RoomWiseCapture {
    private RoomWiseCapture() {}

    public static void main(String[] args) throws Exception {
        TimetableDao dao = new TimetableDao();
        dao.verifySchema();
        capture(dao, false, new File("tmp/roomwise_free.png"));
        capture(dao, true, new File("tmp/roomwise_occupied.png"));
    }

    private static void capture(TimetableDao dao, boolean occupied, File target) throws Exception {
        JFrame[] current = new JFrame[1];
        SwingUtilities.invokeAndWait(() -> {
            JFrame frame = new RoomFinderWindow(dao);
            frame.setSize(900, 560);
            frame.setLocationRelativeTo(null);
            try {
                field(frame, "dayBox", JComboBox.class).setSelectedItem(DayOfWeek.MONDAY);
                field(frame, "timeBox", JComboBox.class).setSelectedItem("9:00");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            frame.setVisible(true);
            current[0] = frame;
        });
        SwingUtilities.invokeAndWait(() -> button(current[0], occupied ? "Occupied" : "Free").doClick());
        SwingUtilities.invokeAndWait(() -> {
            current[0].validate();
            try {
                render(current[0], target);
            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                current[0].dispose();
            }
        });
    }

    private static void render(JFrame frame, File target) throws Exception {
        frame.validate();
        Container content = frame.getContentPane();
        BufferedImage image = new BufferedImage(content.getWidth(), content.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        content.printAll(graphics);
        graphics.dispose();
        ImageIO.write(image, "png", target);
        System.out.println(target + " " + image.getWidth() + "x" + image.getHeight());
    }

    @SuppressWarnings("unchecked")
    private static <T> T field(Object target, String name, Class<T> type) throws Exception {
        Field field = target.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return (T) field.get(target);
    }

    private static JButton button(Container root, String text) {
        for (Component component : root.getComponents()) {
            if (component instanceof JButton candidate && text.equals(candidate.getText())) return candidate;
            if (component instanceof Container nested) {
                JButton found = button(nested, text);
                if (found != null) return found;
            }
        }
        return null;
    }
}
