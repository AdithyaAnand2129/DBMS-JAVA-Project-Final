from pypdf import PdfReader
r=PdfReader(r'C:\Users\adith\Downloads\NAMMA_CHENNAI.pdf')
for term in ['rec log','record log','log sheet','record','bonafide']:
    hits=[i+1 for i,p in enumerate(r.pages) if term in (p.extract_text() or '').lower()]
    print('SEARCH',term,hits[:30],len(hits))
